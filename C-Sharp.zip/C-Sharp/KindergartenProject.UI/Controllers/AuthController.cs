﻿using Microsoft.AspNetCore.Mvc;
using KindergartenProject.Application.Models.VMs;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;

namespace KindergartenProject.UI.Controllers
{
    public class AuthController : Controller
    {
        private readonly HttpClient _httpClient;

        public AuthController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View(); 
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model); 
            }


            var response = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Auth/Login", model);

            if (response.IsSuccessStatusCode)
            {

                var result = await response.Content.ReadFromJsonAsync<LoginResponseDto>();

                if (result != null)
                {

                    // Serialize the LoginResponseDto and store it in session
                    HttpContext.Session.SetString("LoginResponse", JsonSerializer.Serialize(result));
                    HttpContext.Session.SetString("UserRole", result.UserRole);

                    if (result.UserRole == "SchoolAdmin" || result.UserRole == "Teacher" ||
                        result.UserRole == "Parent")
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        //yanlış giriş handling burda olmalı
                        return RedirectToAction("Index", "Home");
                    }
                }
            }


            ModelState.AddModelError("", "Hatalı giriş");
            return View(model);
        }
    }
}
