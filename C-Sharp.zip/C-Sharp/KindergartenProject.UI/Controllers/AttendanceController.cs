﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.VMs;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web.Http.ModelBinding;

namespace KindergartenProject.UI.Controllers
{

    public class AttendanceController : Controller
    {
        private readonly HttpClient _httpClient;

        public AttendanceController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet]
        public async Task<IActionResult> MarkAttendance()
        {
            var viewModel = new AttendanceListViewModel
            {
                Date = DateTime.Now
            };

            try
            {
                // Öğretmenin atanmış sınıf kimliğini al
                int classroomId = 2;// GetAssignedClassroomIdForTeacher();

                // ClassroomId ve Date'e göre yoklama listesi al
                var response = await _httpClient.GetAsync(
                    $"https://localhost:7255/api/Attendance/GetAttendancesByClassroomId?classroomId={classroomId}&date={viewModel.Date:yyyy-MM-dd}"
                );

                if (response.IsSuccessStatusCode)
                {
                    viewModel.Attendances = await response.Content.ReadFromJsonAsync<List<AttendanceViewModel>>();
                }
                else
                {
                    TempData["error"] = "Yoklama listesi alınamadı. Lütfen tekrar deneyin.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"Yoklama listesi alınırken bir hata oluştu: {ex.Message}";
                return View(viewModel); // Hata durumunda sayfayı tekrar göster
            }

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> MarkAttendance(AttendanceListViewModel viewModel)
        {
            try
            {
                var attendanceDtos = viewModel.Attendances.Select(a => new AttendanceCreateDto
                {
                    StudentId = a.StudentId,
                    ClassroomId = 2,//GetAssignedClassroomIdForTeacher(), // classroomId'yi doğrudan burada al
                    Date = viewModel.Date,
                    IsPresent = a.IsPresent
                }).ToList();

                // API'ye yoklama gönder
                var response = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Attendance/MarkAttendance", attendanceDtos);

                if (!response.IsSuccessStatusCode)
                {
                    TempData["error"] = "Yoklama kaydedilirken bir hata oluştu. Lütfen tekrar deneyin.";
                    return View(viewModel); // Hata durumunda sayfayı tekrar göster
                }

                TempData["success"] = "Yoklama başarıyla kaydedildi!";
                return RedirectToAction("MarkAttendance");
            }
            catch (Exception ex)
            {
                TempData["error"] = $"Yoklama kaydedilirken bir hata oluştu: {ex.Message}";
                return View(viewModel);
            }
        }

        // Öğretmenin atanmış sınıf kimliğini alacak method (kendi lojiğine göre düzenle)
        private int GetAssignedClassroomIdForTeacher()
        {
            // Örneğin, öğretmen ID'ye göre classroomId'yi bir servisten alabilirsin
            // Bu örnek static bir değer döndürüyor, kendi lojiğine göre düzenle
            return 2; // Öğretmen belirli bir sınıfa atanmış gibi sabit bir değer döndürüyor.
        }


        [HttpGet]
        public async Task<IActionResult> EditAttendance(int id)
        {
            // API'den veriyi al
            var attendance = await _httpClient.GetFromJsonAsync<AttendanceViewModel>(
                $"https://localhost:7255/api/Attendance/GetAttendanceById/{id}");

            if (attendance == null)
            {
                TempData["error"] = "Yoklama bilgisi bulunamadı.";
                return RedirectToAction("Index", "Home");
            }

            return View(attendance);
        }

        // POST: Attendance/EditAttendance
        [HttpPost]
        public async Task<IActionResult> EditAttendance(AttendanceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                TempData["error"] = "Lütfen tüm alanları doğru doldurun.";
                return View(model);
            }

            try
            {
                // API'ye PUT isteği ile veriyi güncelle
                var response = await _httpClient.PutAsJsonAsync(
                    $"https://localhost:7255/api/Attendance/EditAttendance?id={model.Id}&isPresent={model.IsPresent}",
                    model);

                if (response.IsSuccessStatusCode)
                {
                    TempData["success"] = "Yoklama başarıyla güncellendi!";
                    return RedirectToAction("EditAttendance", new { id = model.Id });
                }
                else
                {
                    TempData["error"] = "Yoklama güncellenemedi. Lütfen tekrar deneyin.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Yoklama güncellenirken bir hata oluştu. Lütfen tekrar deneyin.";
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> DailyAttendance(DateTime date)
        {
            var attendanceList = new List<AttendanceViewModel>();

            try
            {
                attendanceList = await _httpClient.GetFromJsonAsync<List<AttendanceViewModel>>($"https://localhost:7255/api/Attendance/DailyAttendance?date={date}");
            }
            catch (Exception ex)
            {
                TempData["error"] = "Yoklama bilgisi alınamadı. Lütfen tekrar deneyin.";
            }

            return View(attendanceList);
        }
        [HttpGet]
        public async Task<IActionResult> StudentAttendance(int studentId)
        {
            var attendanceList = new List<AttendanceViewModel>();

            try
            {
                attendanceList = await _httpClient.GetFromJsonAsync<List<AttendanceViewModel>>($"https://localhost:7255/api/Attendance/StudentAttendance?studentId={studentId}");
            }
            catch (Exception ex)
            {
                TempData["error"] = "Öğrenci yoklama bilgisi alınamadı. Lütfen tekrar deneyin.";
            }

            return View(attendanceList);
        }


    }

}