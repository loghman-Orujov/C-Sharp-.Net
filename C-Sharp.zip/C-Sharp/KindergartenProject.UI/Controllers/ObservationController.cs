﻿using KindergartenProject.Application.Models.DTOs;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.UI.Controllers
{
    public class ObservationController : Controller
    {
        private readonly HttpClient _httpClient;

        public ObservationController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // GET: Observation/StudentObservations/{studentId}
        [HttpGet]
        public async Task<IActionResult> StudentObservations(int studentId)
        {
            var response = await _httpClient.GetAsync($"https://localhost:7255/api/Observation/GetObservationsByStudentId?studentId={studentId}");
            if (!response.IsSuccessStatusCode)
            {
                TempData["error"] = "Öğrenci gözlem notları alınamadı.";
                return View(new List<ObservationNoteDto>());
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            var observationNotes = JsonConvert.DeserializeObject<List<ObservationNoteDto>>(responseContent);
            return View(observationNotes);
        }

        // GET: Observation/CreateObservation/{studentId}
        [HttpGet]
        public IActionResult CreateObservation(int studentId)
        {
            var model = new ObservationCreateDto { StudentId = studentId };
            return View(model);
        }

        // POST: Observation/CreateObservation
        [HttpPost]
        public async Task<IActionResult> CreateObservation(ObservationCreateDto model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("https://localhost:7255/api/Observation/CreateObservation", content);

            if (response.IsSuccessStatusCode)
            {
                TempData["success"] = "Gözlem notu başarıyla eklendi.";
                return RedirectToAction("StudentObservations", new { studentId = model.StudentId });
            }

            TempData["error"] = "Gözlem notu eklenemedi.";
            return View(model);
        }

        // GET: Observation/EditObservation/{id}
        [HttpGet]
        public async Task<IActionResult> EditObservation(int id)
        {
            var response = await _httpClient.GetAsync($"https://localhost:7255/api/Observation/GetObservationById?id={id}");
            if (!response.IsSuccessStatusCode)
            {
                TempData["error"] = "Gözlem notu bulunamadı.";
                return RedirectToAction("Index", "Home");
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<ObservationUpdateDto>(responseContent);
            return View(model);
        }

        // POST: Observation/EditObservation
        [HttpPost]
        public async Task<IActionResult> EditObservation(ObservationUpdateDto model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync("https://localhost:7255/api/Observation/UpdateObservation", content);

            if (response.IsSuccessStatusCode)
            {
                TempData["success"] = "Gözlem notu başarıyla güncellendi.";
                return RedirectToAction("StudentObservations", new { studentId = model.StudentId });
            }

            TempData["error"] = "Gözlem notu güncellenemedi.";
            return View(model);
        }

        // POST: Observation/DeleteObservation/{id}
        [HttpPost]
        public async Task<IActionResult> DeleteObservation(int id, int studentId)
        {
            var response = await _httpClient.DeleteAsync($"https://localhost:7255/api/Observation/DeleteObservation?id={id}");
            if (response.IsSuccessStatusCode)
            {
                TempData["success"] = "Gözlem notu başarıyla silindi.";
            }
            else
            {
                TempData["error"] = "Gözlem notu silinemedi.";
            }

            return RedirectToAction("StudentObservations", new { studentId });
        }
    }
}
