﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.VMs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ActionConstraints;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;


namespace KindergartenProject.UI.Controllers
{
	public class SchoolAdminController : Controller
	{
        private readonly HttpClient _httpClient;

        public SchoolAdminController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet]
        public IActionResult AddSchoolAdmin()
		{
			return View();
		}

		[HttpPost]
		public async Task<IActionResult> AddSchoolAdmin(SchoolAdminCreateDto model)
		{
			if (!ModelState.IsValid)
			{
				return View(model);
			}

			var response = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/SchoolAdmin/CreateSchoolAdmin", model);
			string fullName = model.FirstName + " " + model.LastName;

			if (response.IsSuccessStatusCode)
			{
				TempData["success"] = fullName + " için yönetici kaydı başarıyla oluşturuldu.";
				return RedirectToAction("Index", "Home");
			}

			TempData["error"] = "Yönetici için hatalı giriş.";
			return View(model);
		}

		public async Task<IActionResult> ListSchoolAdmin()
		{
			var listModel = new List<SchoolAdminListDto>();

			//burda farklı bi metod olarak try catch denedik
			try
			{
				listModel = await _httpClient.GetFromJsonAsync<List<SchoolAdminListDto>>("https://localhost:7255/api/SchoolAdmin/ListSchoolAdmin");
			}
			catch (Exception ex)
			{
				// Exception logla
				TempData["error"] = "Yönetici listesi alınamadı. Lütfen tekrar deneyin.";
			}

			return View(listModel);
		}

		[HttpGet]
        public IActionResult AddTeacher()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddTeacher(TeacherCreateDto model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var response = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Teacher/CreateTeacher", model);
            string fullName = model.FirstName + " " + model.LastName;

            if (response.IsSuccessStatusCode)
            {
                TempData["success"] = fullName + " için öğretmen kaydı başarıyla oluşturuldu.";
                return RedirectToAction("Index", "Home");
            }

            TempData["error"] = "Öğretmen için hatalı giriş.";
            return View(model);
        }

        public async Task<IActionResult> ListTeacher()
        {
			var viewModel = new List<TeacherViewModel>();

			//burda farklı bi metod olarak try catch denedik
			try
			{
				viewModel = await _httpClient.GetFromJsonAsync<List<TeacherViewModel>>("https://localhost:7255/api/Teacher/ListTeacher");
			}
			catch (Exception ex)
			{
				// Exception logla
				TempData["error"] = "Öğretmen listesi alınamadı. Lütfen tekrar deneyin.";
			}

			return View(viewModel);
		}

        [HttpGet]
        public IActionResult AddParent()
        {
            var studentParentViewModel = new AddStudentParentViewModel();

            // Retrieve the student data from TempData
            if (TempData["StudentCreateDTO"] != null)
            {
                var studentData = JsonConvert.DeserializeObject<StudentCreateDTO>(TempData["StudentCreateDTO"].ToString());
                studentParentViewModel.studentCreateDTO = studentData;
            }

            return View(studentParentViewModel);
        }


        [HttpPost]
        public async Task<IActionResult> AddParent(AddStudentParentViewModel studentParentModel)
        {
            // Repopulate StudentCreateDTO from TempData
            if (TempData["StudentCreateDTO"] != null)
            {
                studentParentModel.studentCreateDTO = JsonConvert.DeserializeObject<StudentCreateDTO>(TempData["StudentCreateDTO"].ToString());
            }

            if (!ModelState.IsValid)
            {
                return View(studentParentModel);
            }
            var studentModel = studentParentModel.studentCreateDTO;
            var parentModel = studentParentModel.parentCreateDTO;

            var studentResponse = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Student/CreateStudent", studentModel);
            if (!studentResponse.IsSuccessStatusCode)
            {
                TempData["error"] = "Hata: Student API'den oluşturulamadı.";
                return View(studentParentModel);
            }
            var studentId = await studentResponse.Content.ReadAsAsync<int>();

            var parentResponse = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Parent/CreateParent", parentModel);
            if (!parentResponse.IsSuccessStatusCode)
            {
                TempData["error"] = "Hata: Parent API'den oluşturulamadı.";
                return View(studentParentModel);
            }
            var parentId = await parentResponse.Content.ReadAsAsync<int>();

            string studentFullName = studentModel.FirstName + " " + studentModel.LastName;
            string parentFullName = parentModel.FirstName + " " + parentModel.LastName;

            var studentParentCreateDto = new StudentParentCreateDto
            {
                StudentId = studentId,
                ParentId = parentId
            };

            var studentParentResponse = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/StudentParent/CreateStudentParent", studentParentCreateDto);
            if (!studentParentResponse.IsSuccessStatusCode)
            {
                TempData["error"] = "Hata: Student-Parent ilişkilendirmesi oluşturulamadı.";
                return View(studentParentModel);
            }

            TempData["success"] = studentFullName + " ve " + parentFullName + " başarıyla oluşturuldu.";
            return RedirectToAction("Index", "Home");
        }


        public async Task<IActionResult> ListParent()
        {
            var viewModel = new List<ParentViewModel>();

            //burda farklı bi metod olarak try catch denedik
            try
            {
                viewModel = await _httpClient.GetFromJsonAsync<List<ParentViewModel>>("https://localhost:7255/api/Parent/ListParent");
            }
            catch (Exception ex)
            {
                // Exception logla
                TempData["error"] = "Ebeveyn listesi alınamadı. Lütfen tekrar deneyin.";
            }

            return View(viewModel);
        }

        [HttpGet] // bunları burada kullanmazsan şu hatayı alırsın: AmbiguousMatchException: The request matched multiple endpoints. 
        public async Task<IActionResult> AddStudent()
        {
            var viewModel = new AddStudentViewModel();

            var studentCreateDTO = new StudentCreateDTO();
            viewModel.studentCreateDTO = studentCreateDTO;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7255/");
                HttpResponseMessage response = await client.GetAsync("api/Classroom/ListClassroom");

                if (response.IsSuccessStatusCode)
                {
                    var classroomData = await response.Content.ReadAsStringAsync();
                    viewModel.ClassroomList = JsonConvert.DeserializeObject<List<ClassroomListDto>>(classroomData);
                }
                else
                {
                    viewModel.ClassroomList = new List<ClassroomListDto>();
                }
            }

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> AddStudent(AddStudentViewModel addStudentViewModel)
        {

            if (!ModelState.IsValid)
            {
                // Repopulate the ClassroomList in case of validation failure
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7255/");
                    HttpResponseMessage bPlanResponse = await client.GetAsync("api/Classroom/ListClassroom");

                    if (bPlanResponse.IsSuccessStatusCode)
                    {
                        var classroomData = await bPlanResponse.Content.ReadAsStringAsync();
                        addStudentViewModel.ClassroomList = JsonConvert.DeserializeObject<List<ClassroomListDto>>(classroomData);
                    }
                    else
                    {
                        addStudentViewModel.ClassroomList = new List<ClassroomListDto>(); // Ensure it's not null
                    }
                }

                return View(addStudentViewModel);
            }
            TempData["StudentCreateDTO"] = JsonConvert.SerializeObject(addStudentViewModel.studentCreateDTO);

            return RedirectToAction("AddParent");
        }

        [HttpGet]
        public async Task<IActionResult> ListStudent()
        {
			var viewModel = new List<StudentViewModel>();

            //burda farklı bi metod olarak try catch denedik
			try
			{
				viewModel = await _httpClient.GetFromJsonAsync<List<StudentViewModel>>("https://localhost:7255/api/Student/ListStudent");
			}
			catch (Exception ex)
			{
				// Exception logla
				TempData["error"] = "Öğrenci listesi alınamadı. Lütfen tekrar deneyin.";
			}

			return View(viewModel);
		}

        [HttpGet] // bunları burada kullanmazsan şu hatayı alırsın: AmbiguousMatchException: The request matched multiple endpoints. 
        public async Task<IActionResult> AddClassroom()
        {
            var viewModel = new AddTeacherClassroomViewModel();

            var classromCreateDto = new ClassromCreateDto();
            viewModel.classromCreateDto = classromCreateDto;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:7255/");
                HttpResponseMessage response = await client.GetAsync("api/Teacher/ListTeacher");

                if (response.IsSuccessStatusCode)
                {
                    var teacherData = await response.Content.ReadAsStringAsync();
                    viewModel.TeacherList = JsonConvert.DeserializeObject<List<TeacherListDto>>(teacherData);//burada classroomdata bir daha bak
                }
                else
                {
                    viewModel.TeacherList = new List<TeacherListDto>();
                }
            }

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> AddClassroom(AddTeacherClassroomViewModel addTeacherClassroomViewModel)
        {

            if (!ModelState.IsValid)
            {
                // Repopulate the ClassroomList in case of validation failure
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7255/");
                    HttpResponseMessage bPlanResponse = await client.GetAsync("api/Teacher/ListTeacher");

                    if (bPlanResponse.IsSuccessStatusCode)
                    {
                        var teacherData = await bPlanResponse.Content.ReadAsStringAsync();
                        addTeacherClassroomViewModel.TeacherList = JsonConvert.DeserializeObject<List<TeacherListDto>>(teacherData);
                    }
                    else
                    {
                        addTeacherClassroomViewModel.TeacherList = new List<TeacherListDto>(); // Ensure it's not null
                    }
                }

                return View(addTeacherClassroomViewModel);
            }
            TempData["ClassromCreateDTO"] = JsonConvert.SerializeObject(addTeacherClassroomViewModel.classromCreateDto);

            return RedirectToAction("AddTeacher");
        }

        public async Task<IActionResult> ListClassroom() 
        {
            var viewModel = new List<ClassroomViewModel>();

            try
            {
                viewModel = await _httpClient.GetFromJsonAsync<List<ClassroomViewModel>>("https://localhost:7255/api/Classroom/ListClassroom");
            }
            catch (Exception ex)
            {
                // Exception logla
                TempData["error"] = "Sınıf listesi alınamadı. Lütfen tekrar deneyin.";
            }

            return View(viewModel);
        }

        [HttpGet]
        public IActionResult CreateWeeklyMenu()
        {
            var model = new WeeklyMenuCreateDto
            {
                DailyMenus = new List<DailyMenuCreateDto>()
            };

            for (int i = 0; i < 5; i++)  // Assuming a 5-day week
            {
                var dailyMenu = new DailyMenuCreateDto
                {
                    DayOfWeek = (DayOfWeek)(i + 1),  // You can adjust this logic for day selection
                    MenuItems = new List<MenuItemCreateDto>()
                };

                for (int j = 0; j < 2; j++)  // Assuming each day has 2 menu items
                {
                    dailyMenu.MenuItems.Add(new MenuItemCreateDto());  // Add an empty MenuItemDto
                }

                model.DailyMenus.Add(dailyMenu);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CreateWeeklyMenu(WeeklyMenuCreateDto weeklyMenuCreateDto)
        {
            if (!ModelState.IsValid)
            {
                return View(weeklyMenuCreateDto);
            }

            var response = await _httpClient.PostAsJsonAsync("https://localhost:7255/api/Menu/CreateWeeklyMenu", weeklyMenuCreateDto);
            if (response.IsSuccessStatusCode)
            {
                TempData["success"] = "Haftalık menü başarıyla oluşturuldu";
                return RedirectToAction("Index", "Home");
            }

            TempData["error"] = "Hatalı giriş.";
            return View(weeklyMenuCreateDto);
        }

		[HttpPut("DeleteStudent/{studentId}")]
		public async Task<IActionResult> DeleteStudent(int studentId)
        {
            var getResponse = await _httpClient.GetFromJsonAsync<Student>($"https://localhost:7255/api/Student/GetById?id={studentId}");
            if (getResponse == null)
            {
                TempData["error"] = "Öğrenci silinirken hata: API öğrenciyi ararken başarıyla döndürmedi.";
            }

            var deleteResponse = await _httpClient.PutAsJsonAsync("https://localhost:7255/api/Student/IsActiveFalse", studentId);
            if (!deleteResponse.IsSuccessStatusCode)
            {
                TempData["error"] = "Öğrenci silinirken hata: API öğrenciyi silerken başarı döndürmedi.";
            }

            TempData["success"] = "Öğrenci başarıyla silindi.";
            return RedirectToAction("ListStudent", "SchoolAdmin");
        }
    }
}
