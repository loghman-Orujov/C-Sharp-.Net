using System.Text;
using AutoMapper;
using KindergartenProject.Application.Managers;
using KindergartenProject.Application.Mappings;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using KindergartenProject.Infrastructure.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;


namespace KindergartenProject.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Configure CORS policy
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", builder =>
                {
                    builder.AllowAnyOrigin()
                           .AllowAnyMethod()
                           .AllowAnyHeader();
                });
            });

            // JWT Configuration
            var jwtSettings = builder.Configuration.GetSection("Jwt");
            var secretKey = Encoding.UTF8.GetBytes(jwtSettings["Key"]);

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwtSettings["Issuer"],
                    ValidAudience = jwtSettings["Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(secretKey),
                    ClockSkew = TimeSpan.Zero 
                };
            });

            //builder.Services.AddDbContext<AppDbContext>(options =>
            //   options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
            //   new MySqlServerVersion(new Version(9, 0, 0))));

            builder.Services.AddDbContext<AppDbContext>(options =>
                 options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // Add services to the container.
            builder.Services.AddControllers();

            // Swagger
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            MapperConfiguration configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

            builder.Services.AddSingleton(typeof(IMapper), configuration.CreateMapper());

            // Repositories and services
            builder.Services.AddScoped<IAppUserService, AppUserManager>();
            builder.Services.AddScoped<IAppUserRepository, AppUserRepository>();

            builder.Services.AddScoped<ITeacherService, TeacherManager>();
            builder.Services.AddScoped<ITeacherRepository, TeacherRepository>();

            builder.Services.AddScoped<IStudentService, StudentManager>();
            builder.Services.AddScoped<IStudentRepository, StudentRepository>();

            builder.Services.AddScoped<IClassroomService, ClassroomManager>();
            builder.Services.AddScoped<IClassroomRepository, ClassroomRepository>();

            builder.Services.AddScoped<IParentService, ParentManager>();
            builder.Services.AddScoped<IParentRepository, ParentRepository>();

            builder.Services.AddScoped<IWeeklyMenuService, WeeklyMenuManager>();
            builder.Services.AddScoped<IWeeklyMenuRepository, WeeklyMenuRepository>();

            builder.Services.AddScoped<IStudentParentService, StudentParentManager>();
            builder.Services.AddScoped<IStudentParentRepository, StudentParentRepository>();

            builder.Services.AddScoped<IWeeklyScheduleService, WeeklyScheduleManager>();
            builder.Services.AddScoped<IWeeklyScheduleRepository, WeeklyScheduleRepository>();

            builder.Services.AddScoped<ISchoolAdminService, SchoolAdminManager>();
            builder.Services.AddScoped<ISchoolAdminRepository, SchoolAdminRepository>();

            builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection("Jwt"));
            builder.Services.AddScoped<IAttendanceService, AttendanceManager>();
            builder.Services.AddScoped<IAttendanceRepository, AttendanceRepository>();

         /*   builder.Services.AddScoped<IObservationService, ObservationManager>();
            builder.Services.AddScoped<IObservationRepository, ObservationRepository>();*/




            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            // Use CORS middleware
            app.UseCors("AllowAll");

            // JWT Authentication middleware
            app.UseAuthentication();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}