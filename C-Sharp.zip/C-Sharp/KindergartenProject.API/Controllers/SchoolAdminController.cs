﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{
	[Route("api/[controller]/[action]")]
	[ApiController]
	public class SchoolAdminController : ControllerBase
	{
		private readonly ISchoolAdminService _service;

		public SchoolAdminController(ISchoolAdminService service)
		{
			_service = service;
		}

		[HttpPost]
		public async Task<IActionResult> CreateSchoolAdmin(SchoolAdminCreateDto schoolAdminCreateDto) 
		{
			if (schoolAdminCreateDto == null) 
			{
				return BadRequest("SchoolAdmin verisi boş olamaz");
			}
			await _service.Add(schoolAdminCreateDto);
			return Ok();
		}

		[HttpGet]
		public async Task<IActionResult> ListSchoolAdmin() 
		{
			var schoolAdmins = await _service.GetAll();
			return Ok(schoolAdmins);
		}

		[HttpPut]
		public async Task<IActionResult> UpdateSchoolAdmin(SchoolAdminUpdateDto schoolAdminUpdateDto)
		{
			await _service.Update(schoolAdminUpdateDto);
			return Ok();
		}

		[HttpPut]
		public async Task<IActionResult> IsActiveFalse(int id)
		{
			await _service.IsActive(id);
			return Ok();
		}

		[HttpGet]
		public async Task<IActionResult> GetById(int id)
		{
			var schoolAdmin = await _service.GetById(id);
			return Ok(schoolAdmin);
		}
	}
}
