using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAppUserService _service;

        public AuthController(IAppUserService service)
        {
            _service = service;
        }
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var users = await _service.GetAll();
            return Ok(users);
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginDto request)
        {
            if (request == null)
            {
                return BadRequest("Login data cannot be null.");
            }
            var userInfo = await _service.Login(request);
            if(userInfo!=null){
                var token = await _service.GenerateToken("1");
                userInfo.Token=token;
            }
            return Ok(userInfo);
        }

    }
}