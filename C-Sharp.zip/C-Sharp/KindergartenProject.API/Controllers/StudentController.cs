using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _service;
        public StudentController(IStudentService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> CreateStudent(StudentCreateDTO studentCreateDTO)
        {
             if (studentCreateDTO == null)
            {
                return BadRequest("Student verisi bos olamaz.");
            }
            var studentId = await _service.Add(studentCreateDTO);
            return Ok(studentId);
        }


        [HttpGet]
        public async Task<IActionResult> ListStudent()
        {
            var students= await _service.GetAll();
            return Ok(students);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateStudent(StudentUpdateDto studentUpdateDto)
        {
            await _service.Update(studentUpdateDto);
            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> IsActiveFalse(int id)
        {
            await _service.IsActive(id);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {
            var student = await _service.GetById(id);
            return Ok(student);
        }
    }
}