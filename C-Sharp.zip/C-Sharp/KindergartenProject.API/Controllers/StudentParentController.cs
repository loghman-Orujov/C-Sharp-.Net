﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class StudentParentController : ControllerBase
    {
        private readonly IStudentParentService _service;
        public StudentParentController(IStudentParentService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> CreateStudentParent(StudentParentCreateDto studentParentCreateDto)
        {
            if(studentParentCreateDto == null)
            {
                return BadRequest("StudentParent data boş olamaz");
            }

            await _service.Add(studentParentCreateDto);
            return Ok();
        }
    }
}
