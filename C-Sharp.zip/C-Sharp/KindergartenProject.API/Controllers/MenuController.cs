using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

[Route("api/[controller]/[action]")]
[ApiController]
public class MenuController : ControllerBase
{
    private readonly IWeeklyMenuService _weeklyMenuService;

    public MenuController(IWeeklyMenuService weeklyMenuService)
    {
        _weeklyMenuService = weeklyMenuService;
    }

    [HttpPost]
    public async Task<IActionResult> CreateWeeklyMenu(WeeklyMenuCreateDto createDTO)
    {
        if (createDTO == null || createDTO.DailyMenus == null || createDTO.DailyMenus.Count == 0)
        {
            return BadRequest("Invalid data.");
        }

        // WeeklyMenu ve DailyMenu'ları birlikte kaydediyoruz.
        await _weeklyMenuService.Add(createDTO);

        return Ok("Weekly menu and daily menus created successfully.");
    }
    [HttpGet]
    public async Task<IActionResult> GetCurrentWeekMenu()
    {
        var currentDate = DateTime.Now;
        var startOfWeek = currentDate.AddDays(-(int)currentDate.DayOfWeek + (int)DayOfWeek.Monday).Date;
        var endOfWeek = startOfWeek.AddDays(4).Date;

        var menu = await _weeklyMenuService.GetWeeklyMenuByDateRange(startOfWeek, endOfWeek);
        return Ok(menu);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllMenu()
    {
        var menu = await _weeklyMenuService.GetAllWeeklyMenu();
        return Ok(menu);
    }


    [HttpPut]
    public async Task<IActionResult> UpdateMenu(WeeklyMenuListDto weeklyMenuUpdate)
    {
        await _weeklyMenuService.Update(weeklyMenuUpdate);
        return Ok();
    }

}
