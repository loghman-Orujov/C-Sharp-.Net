﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ParentController : ControllerBase
    {
        private readonly IParentService _service;
        public ParentController(IParentService service)
        {
            _service = service;
        }
        [HttpPost]
        public async Task<IActionResult> CreateParent(ParentCreateDto parentCreateDto)
        {
            if (parentCreateDto == null)
            {
                return BadRequest("Parent verisi boş olamaz");
            }
            var parentId = await _service.Add(parentCreateDto);
            return Ok(parentId);
        }

        [HttpGet]
        public async Task<IActionResult> ListParent()
        {
            var parent = await _service.GetAll();
            return Ok(parent);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateParent(ParentUpdateDto parentUpdateDto)
        {
            await _service.Update(parentUpdateDto);
            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> IsActiveFalse(int id)
        {
            await _service.IsActive(id);
            return Ok();
        }
    }
}