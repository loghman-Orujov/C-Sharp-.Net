﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceService _service;

        public AttendanceController(IAttendanceService service)
        {
            _service = service;
        }

        // Belirli bir yoklama kaydını ID ile getirir
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAttendanceById(int id)
        {
            var attendance = await _service.GetAttendanceByIdAsync(id);

            if (attendance == null)
            {
                return NotFound($"Attendance with ID {id} not found.");
            }

            var attendanceDto = new AttendanceDto
            {
                Id = attendance.Id,
                StudentId = attendance.StudentId,
                StudentName = attendance.StudentName,
                ClassroomId = attendance.ClassroomId,
                ClassName = attendance.ClassName,
                Date = attendance.Date,
                IsPresent = attendance.IsPresent
            };

            return Ok(attendanceDto);
        }


        // Tüm yoklama kayıtlarını getirir
        [HttpGet]
        public async Task<IActionResult> GetAllAttendances()
        {
            try
            {
                var attendances = await _service.GetAllAttendancesAsync();

                if (attendances == null || !attendances.Any())
                {
                    return NotFound("No attendance records found.");
                }

                var attendanceDtos = attendances.Select(attendance => new AttendanceDto
                {
                    Id = attendance.Id,
                    StudentId = attendance.StudentId,
                    StudentName = attendance.StudentName,
                    ClassroomId = attendance.ClassroomId,
                    ClassName = attendance.ClassName,
                    Date = attendance.Date,
                    IsPresent = attendance.IsPresent
                }).ToList();

                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                // Hata loglama işlemi yapılabilir
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Belirli bir öğrenciye ait yoklamaları getirir
        [HttpGet("{studentId}")]
        public async Task<IActionResult> GetStudentAttendance(int studentId)
        {
            try
            {
                var attendances = await _service.StudentAttendanceAsync(studentId);

                if (attendances == null || !attendances.Any())
                {
                    return NotFound($"No attendance records found for student ID {studentId}.");
                }

                var attendanceDtos = attendances.Select(attendance => new AttendanceDto
                {
                    Id = attendance.Id,
                    StudentId = attendance.StudentId,
                    StudentName = attendance.StudentName,
                    ClassroomId = attendance.ClassroomId,
                    ClassName = attendance.ClassName,
                    Date = attendance.Date,
                    IsPresent = attendance.IsPresent
                }).ToList();

                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                // Hata loglama yapılabilir
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        // Belirli bir sınıfa ait yoklamaları getirir
        [HttpGet("{classroomId}")]
        public async Task<IActionResult> GetAttendancesByClassroomId(int classroomId)
        {
            try
            {
                var attendances = await _service.GetAttendancesByClassroomIdAsync(classroomId);

                if (attendances == null || !attendances.Any())
                {
                    return NotFound($"No attendance records found for classroom ID {classroomId}.");
                }

                var attendanceDtos = attendances.Select(attendance => new AttendanceDto
                {
                    Id = attendance.Id,
                    StudentId = attendance.StudentId,
                    StudentName = attendance.StudentName,
                    ClassroomId = attendance.ClassroomId,
                    ClassName = attendance.ClassName,
                    Date = attendance.Date,
                    IsPresent = attendance.IsPresent
                }).ToList();

                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                // Consider logging the exception here
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        // Belirli bir tarihe ait tüm yoklamaları getirir
        [HttpGet("{date}")]
        public async Task<IActionResult> GetDailyAttendance(DateTime date)
        {
            try
            {
                var attendances = await _service.DailyAttendanceAsync(date);

                if (attendances == null || !attendances.Any())
                {
                    return NotFound($"No attendance records found for date {date.ToShortDateString()}.");
                }

                var attendanceDtos = attendances.Select(attendance => new AttendanceDto
                {
                    Id = attendance.Id,
                    StudentId = attendance.StudentId,
                    StudentName = attendance.StudentName,
                    ClassroomId = attendance.ClassroomId,
                    ClassName = attendance.ClassName,
                    Date = attendance.Date,
                    IsPresent = attendance.IsPresent
                }).ToList();

                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                // Consider logging the exception here
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        // Yoklama işaretleme işlemi
        [HttpPost]
        public async Task<IActionResult> MarkAttendance(List<AttendanceDto> attendanceList)
        {
            // Gelen yoklama listesi üzerinde işlem yap
            var success = await _service.MarkAttendanceAsync(attendanceList);
            if (!success)
            {
                return BadRequest("Failed to mark attendance.");
            }
            return Ok("Attendance marked successfully.");
        }

        // Mevcut bir yoklamayı güncelleme işlemi
        [HttpPut]
        public async Task<IActionResult> EditAttendance(int id, bool isPresent)
        {
            var success = await _service.EditAttendanceAsync(id, isPresent);
            if (!success)
            {
                return BadRequest($"Failed to update attendance with ID {id}.");
            }
            return Ok("Attendance updated successfully.");
        }


        // Yoklama doğrulama işlemi
        [HttpPost("Validate")]
        public async Task<IActionResult> ValidateAttendance(int studentId, DateTime date)
        {
            var isValid = await _service.ValidateAttendanceAsync(studentId, date);
            if (!isValid)
            {
                return BadRequest("Attendance validation failed.");
            }
            return Ok("Attendance is valid.");
        }
        // Yoklama kaydını silme işlemi (IsActiveFalse işlemi)
        [HttpPut]
        public async Task<IActionResult> IsActiveFalse(int id)
        {
            await _service.IsActive(id);
            return Ok();
        }
    }
}
