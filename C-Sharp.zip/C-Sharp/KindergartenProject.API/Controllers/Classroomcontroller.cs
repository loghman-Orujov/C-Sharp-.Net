using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace KindergartenProject.API.Controllers
{
   [Route("api/[controller]/[action]")]
    [ApiController]
    public class ClassroomController : ControllerBase
    {
        private readonly IClassroomService _service;
        public ClassroomController (IClassroomService service)
        {
            _service = service;
        }

         [HttpPost]
        public async Task<IActionResult> CreateClasroom(ClassromCreateDto classromCreateDto)
        {
             if (classromCreateDto == null)
            {
                return BadRequest("Classroom data cannot be null.");
            }
            await _service.Add(classromCreateDto);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> ListClassroom()
        {
            var classroom= await _service.GetAll();
            return Ok(classroom);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateClassrom(ClassroomListDto updateClassrom)
        {
             await _service.Update(updateClassrom);
             return Ok();
        }


        [HttpPut]
        public async Task<IActionResult> IsActiveFalse(int id)
        {
            await _service.IsActive(id);
            return Ok();
        }
    }
}