﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ObservationController : ControllerBase
    {
        private readonly IObservationService _observationService;

        public ObservationController(IObservationService observationService)
        {
            _observationService = observationService;
        }

        // GET: api/Observation/GetObservationsByStudentId?studentId={studentId}
        [HttpGet("GetObservationsByStudentId")]
        public async Task<IActionResult> GetObservationsByStudentId(int studentId)
        {
            var result = await _observationService.GetObservationsByStudentIdAsync(studentId);
            if (result == null || result.Count == 0)
            {
                return NotFound("Observation notes not found.");
            }
            return Ok(result);
        }

        // GET: api/Observation/GetObservationById?id={id}
        [HttpGet("GetObservationById")]
        public async Task<IActionResult> GetObservationById(int id)
        {
            var observation = await _observationService.GetObservationByIdAsync(id);
            if (observation == null)
            {
                return NotFound("Observation note not found.");
            }
            return Ok(observation);
        }

        // POST: api/Observation/CreateObservation
        [HttpPost("CreateObservation")]
        public async Task<IActionResult> CreateObservation([FromBody] ObservationCreateDto observationCreateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _observationService.CreateObservationNoteAsync(observationCreateDto);
            return Ok("Observation note created successfully.");
        }

        // PUT: api/Observation/UpdateObservation
        [HttpPut("UpdateObservation")]
        public async Task<IActionResult> UpdateObservation([FromBody] ObservationUpdateDto observationUpdateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _observationService.UpdateObservationNoteAsync(observationUpdateDto);
            return Ok("Observation note updated successfully.");
        }

        // DELETE: api/Observation/DeleteObservation?id={id}
        [HttpDelete("DeleteObservation")]
        public async Task<IActionResult> DeleteObservation(int id)
        {
            await _observationService.DeleteObservationNoteAsync(id);
            return Ok("Observation note deleted successfully.");
        }
    }
}
