using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class WeeklySchedulesController : ControllerBase
    {
        private readonly IWeeklyScheduleService _service;

        public WeeklySchedulesController(IWeeklyScheduleService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> CreateWeeklySchedule(WeeklyScheduleCreateDto weeklyScheduleCreateDto)
        {
            if (weeklyScheduleCreateDto == null)
            {
                return BadRequest("Teacher data cannot be null.");
            }
            await _service.Add(weeklyScheduleCreateDto);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetCurrentWeekSchedule()
        {
            var currentDate = DateTime.Now;
            var startOfWeek = currentDate.AddDays(-(int)currentDate.DayOfWeek + (int)DayOfWeek.Monday).Date;
            var endOfWeek = startOfWeek.AddDays(4).Date;

            var menu = await _service.GetWeeklyScheduleByDateRange(startOfWeek, endOfWeek);
            return Ok(menu);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllSchedule()
        {
            var menu = await _service.GetAllWeeklySchedule();
            return Ok(menu);
        }


        [HttpPut]
        public async Task<IActionResult> UpdateSchedule(WeeklyScheduleListDto weeklyScheduleUpdate)
        {
            await _service.Update(weeklyScheduleUpdate);
            return Ok();
        }
    }
}