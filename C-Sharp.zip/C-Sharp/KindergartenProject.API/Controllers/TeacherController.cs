using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace KindergartenProject.API.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherService _service;
        public TeacherController(ITeacherService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTeacher(TeacherCreateDto teacherCreateDto)
        {
            if (teacherCreateDto == null)
            {
                return BadRequest("Teacher data cannot be null.");
            }
            await _service.Add(teacherCreateDto);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> ListTeacher()
        {
            var teachers= await _service.GetAll();
            return Ok(teachers);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateTeacher(TeacherUpdateDto teacherUpdateDto)
        {
             await _service.Update(teacherUpdateDto);
             return Ok();
        }


        [HttpPut]
        public async Task<IActionResult> IsActiveFalse(int id)
        {
            await _service.IsActive(id);
            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {
           var teacher= await _service.GetById(id);
            return Ok(teacher);
        }
    }
}