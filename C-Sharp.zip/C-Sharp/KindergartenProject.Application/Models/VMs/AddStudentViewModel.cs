﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.VMs
{
    public class AddStudentViewModel
    {
        public List<ClassroomListDto>? ClassroomList { get; set; }
        public StudentCreateDTO? studentCreateDTO { get; set; }
    }
}
