﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.VMs
{
    public class AddStudentParentViewModel
    {
        public StudentCreateDTO? studentCreateDTO { get; set; }
        public ParentCreateDto? parentCreateDTO { get; set; }
    }
}
