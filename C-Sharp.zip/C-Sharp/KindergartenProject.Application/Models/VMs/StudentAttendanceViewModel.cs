﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.VMs
{
    public class StudentAttendanceViewModel
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }

        // Öğrencinin yoklama geçmişi
        public IEnumerable<AttendanceDto> AttendanceRecords { get; set; }

        // Mevcut tarihi göstermek için kullanılabilir (isteğe bağlı)
        public DateTime CurrentDate { get; set; }

    }
}
