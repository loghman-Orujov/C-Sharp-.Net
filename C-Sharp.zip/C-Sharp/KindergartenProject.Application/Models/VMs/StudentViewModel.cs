﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.VMs
{
	public class StudentViewModel
	{
        public int StudentId { get; set; }

        [Required(ErrorMessage = "İsim boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "İsim 30 karakterden uzun olamaz.")]
        public string FirstName { get; set; }

        [MaxLength(30, ErrorMessage = "Soyisim 30 karakterden uzun olamaz.")]
        [Required(ErrorMessage = "Soysim boş bırakılamaz.")]
        public string LastName { get; set; }

        [MaxLength(30, ErrorMessage = "Cinsiyet 30 karakterden uzun olamaz.")]
        [Required(ErrorMessage = "Cinsiyet boş bırakılamaz.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Yaş boş bırakılamaz.")]
        [Range(3, 14, ErrorMessage = "Yaş 3-14 aralığında olmalıdır.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Okul No")]
        public int SchoolNo { get; set; }

        [MaxLength(500, ErrorMessage = "Alerjiler 500 karakterden uzun olamaz.")]
        public string Allergies { get; set; }

        [MaxLength(500, ErrorMessage = "Hastalıklar 500 karakterden uzun olamaz.")]
        public string Diseases { get; set; }

        [Required(ErrorMessage = "Kan grubu boş bırakılamaz.")]
        public string BloodType { get; set; }

        [MaxLength(500, ErrorMessage = "İlaçlar 500 karakterden uzun olamaz.")]
        public string Medications { get; set; }

        [MaxLength(500, ErrorMessage = "Diyet notları 500 karakterden uzun olamaz.")]
        public string DietNotes { get; set; }

        //public ICollection<Parent> Parents { get; set; }	// many to many relationship

        [Required(ErrorMessage = "Acil durum kişileri boş bırakılamaz")]
        [MaxLength(500, ErrorMessage = "Acil durum kişileri 500 karakterden uzun olamaz.")]
        public string EmergencyContact { get; set; }

		[Required(ErrorMessage = "Sınıf boş bırakılamaz.")]
		public int ClassroomId { get; set; }
	}
}
