using System;
using System.ComponentModel.DataAnnotations;

namespace KindergartenProject.Application.Models.VMs.VMs
{
    public class AppRoleViewModel
    {
        public string RoleName { get; set; }

    }
}
