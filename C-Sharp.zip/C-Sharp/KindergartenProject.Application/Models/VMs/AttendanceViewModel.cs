﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.VMs
{
    public class AttendanceViewModel
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int ClassroomId { get; set; }
        public string ClassName { get; set; }
        public DateTime Date { get; set; }
        public bool IsPresent { get; set; }
    }
}
