using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Models.DTOs
{
    public class DailyMenuListDto
    {
        public int id { get; set; }
        public DayOfWeek DayOfWeek { get; set; }
        public List<MenuItemCreateDto> MenuItems { get; set; }
    }
}