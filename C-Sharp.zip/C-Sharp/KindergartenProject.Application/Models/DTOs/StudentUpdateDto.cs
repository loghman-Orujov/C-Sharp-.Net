﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class StudentUpdateDto
    {
        public int StudentId { get; set; } // bunun burada olmaması lazım, DB içindeki id değil öğrenciNo ile güncellenmeli

        [Required(ErrorMessage = "İsim boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "İsim 30 karakterden uzun olamaz.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Soyisim boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "Soyisim 30 karakterden uzun olamaz.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Cinsiyet boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "Cinsiyet 30 karakterden uzun olamaz.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Cinsiyet boş bırakılamaz.")]
        [Range(3, 14, ErrorMessage = "Yaş 3-14 aralığında olmalıdır.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Okul no boş bırakılamaz.")]
        public int SchoolNo { get; set; }

        [MaxLength(500, ErrorMessage = "Alerjiler 500 karakterden uzun olamaz.")]
        public string? Allergies { get; set; }

        [MaxLength(500, ErrorMessage = "Hastalıklar 500 karakterden uzun olamaz.")]
        public string? Diseases { get; set; }

        [Required(ErrorMessage = "Kan grubu boş bırakılamaz.")]
        [MaxLength(10, ErrorMessage = "Kan grubu 10 karakterden uzun olamaz.")]
        public string BloodType { get; set; }

        [MaxLength(500, ErrorMessage = "İlaçlar 500 karakterden uzun olamaz.")]
        public string? Medications { get; set; }
        
        [MaxLength(500, ErrorMessage = "Diyet notları 500 karakterden uzun olamaz.")]
        public string? DietNotes { get; set; }

        [Required(ErrorMessage = "Acil durum kişisi boş bırakılamaz.")]
        [MaxLength(500, ErrorMessage = "Acil durum kişisi 500 karakterden uzun olamaz.")]
        public string EmergencyContact { get; set; }

        [Required(ErrorMessage = "Öğrencinin ait olduğu sınıf boş bırakılamaz.")]
        public int ClassroomId { get; set; }
    }
}
