using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Models.DTOs
{
    public class TeacherCreateDto
    {
        [Required(ErrorMessage = "E-mail bo� b�rak�lamaz.")]
        [MaxLength(254, ErrorMessage = "E-mail 254 karakterden uzun olamaz.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Bir �ifre belirlemelisiniz.")]
        [MaxLength(20, ErrorMessage = "�ifre 20 karakterden uzun olamaz.")]
        [MinLength(8, ErrorMessage = "�ifre 8 karakterden k�sa olamaz.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "�sim bo� b�rak�lamaz.")]
        [MaxLength(30, ErrorMessage = "�sim 30 karakterden uzun olamaz.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Soysim bo� b�rak�lamaz.")]
        [MaxLength(30, ErrorMessage = "Soysim 30 karakterden uzun olamaz.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Cinsiyet bo� b�rak�lamaz.")]
        [MaxLength(30, ErrorMessage = "Cinsiyet 30 karakterden uzun olamaz.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Telefon numaras� bo� b�rak�lamaz.")]
        [MaxLength(30, ErrorMessage = "Telefon numaras� 15 karakterden uzun olamaz.")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Bran� bo� b�rak�lamaz.")]
        [MaxLength(100, ErrorMessage = "Bran� 100 karakterden uzun olamaz.")]
        public string SubjectSpecialization { get; set; }
    }
}