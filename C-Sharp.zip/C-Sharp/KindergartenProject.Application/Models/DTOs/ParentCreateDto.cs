﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.EnumUserRoles;

namespace KindergartenProject.Application.Models.DTOs
{
    public class ParentCreateDto
    {
        [Required(ErrorMessage = "İsim boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "İsim 30 karakterden uzun olamaz.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Soysim boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "Soysim 30 karakterden uzun olamaz.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "E-mail boş bırakılamaz.")]
        [MaxLength(254, ErrorMessage = "E-mail 254 karakterden uzun olamaz.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Bir şifre belirlemelisiniz.")]
        [MaxLength(20, ErrorMessage = "Şifre 20 karakterden uzun olamaz.")]
        [MinLength(8, ErrorMessage = "Şifre 8 karakterden kısa olamaz.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Cinsiyet boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "Cinsiyet 30 karakterden uzun olamaz.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Telefon numarası boş bırakılamaz.")]
        [MaxLength(30, ErrorMessage = "Telefon numarası 15 karakterden uzun olamaz.")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [StringLength(100, ErrorMessage = "Lastname cannot be longer than 50 characters")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Meslek boş bırakılamaz.")]
        [MaxLength(100, ErrorMessage = "Meslek 100 karakterden uzun olamaz.")]
        public string Occupation { get; set; }

        public ICollection<StudentParent>? StudentParents { get; set; }
    }
}
