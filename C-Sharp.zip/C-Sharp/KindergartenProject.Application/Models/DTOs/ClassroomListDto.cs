using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class ClassroomListDto
    {
        public int ClassroomId { get; set; }
        public string ClassName { get; set; }
        public int Capacity { get; set; }


    }
}