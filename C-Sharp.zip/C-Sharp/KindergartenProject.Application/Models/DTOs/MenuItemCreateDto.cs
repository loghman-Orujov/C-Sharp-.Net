using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class MenuItemCreateDto
    {
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public int Calories { get; set; }
    }
}