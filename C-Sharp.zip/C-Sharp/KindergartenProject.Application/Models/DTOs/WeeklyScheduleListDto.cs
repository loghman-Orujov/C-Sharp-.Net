using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Models.DTOs
{
    public class WeeklyScheduleListDto
    {
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<DailyScheduleCreateDto> DailySchedules { get; set; }
    }
}