using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;

namespace KindergartenProject.Domain.Entities
{
    public class DailyScheduleCreateDto 
    {
        public DayOfWeek DayOfWeek { get; set; } 
        public List<ActivitiyCreateDto> Activities { get; set; } 
        
    }

}