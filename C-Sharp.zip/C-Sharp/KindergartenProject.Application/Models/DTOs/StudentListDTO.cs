﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
	public class StudentListDTO
	{
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public int SchoolNo { get; set; }
        public string Allergies { get; set; }
        public string Diseases { get; set; }
        public string BloodType { get; set; }
        public string Medications { get; set; }
        public string DietNotes { get; set; }
        //public ICollection<Parent> Parents { get; set; }	// many to many relationship
        public string EmergencyContact { get; set; }
        public int ClassroomID { get; set; }
        
        
    }
}
