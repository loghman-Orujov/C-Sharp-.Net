using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class ClassromCreateDto
    {
        [Required(ErrorMessage = "S�n�f ismi bo� b�rak�lamaz.")]
        [MaxLength(20, ErrorMessage = "S�n�f ismi 20 karakterden uzun olamaz.")]
        public string ClassName { get; set; }

        [Required(ErrorMessage = "Kapasite bo� b�rak�lamaz.")]
        public int Capacity { get; set; }
        public int TeacherId { get; set; }
        
        
    }
}