﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class ObservationNoteDto
    {
        public int Id { get; set; }
        public string Note { get; set; } // Öğretmenin girdiği not
        public string Observation { get; set; } // Öğretmenin gözlemi
        public DateTime Date { get; set; } // Gözlem tarihi
        public int StudentId { get; set; } // İlişkili öğrenci ID'si
        public string StudentName { get; set; } // İlişkili öğrenci adı
        public int DevelopmentalAreaId { get; set; } // Gelişim alanı ID'si
        public string DevelopmentalAreaName { get; set; } // Gelişim alanı adı
    }
}
