using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs.DTOs
{
    public class AppRoleCreateDto
    {
        public string RoleName { get; set; }
    }
}