using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Models.DTOs
{
    public class WeeklyMenuListDto
    {
        public int id { get; set; }
        public DateTime WeekStartDate { get; set; }
        public DateTime WeekEndDate { get; set; }
        public List<DailyMenuCreateDto> DailyMenus { get; set; }
    }
}