﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Models.DTOs
{
    public class AttendanceUpdateDto
    {
        public int Id { get; set; }          // Güncellenmekte olan yoklama kaydının ID'si
        public int StudentId { get; set; }   // Öğrencinin ID'si
        public int ClassroomId { get; set; } // Sınıfın ID'si
        public DateTime Date { get; set; }   // Yoklama tarihi
        public bool IsPresent { get; set; }  // Öğrencinin yoklama durumu
    }
}
