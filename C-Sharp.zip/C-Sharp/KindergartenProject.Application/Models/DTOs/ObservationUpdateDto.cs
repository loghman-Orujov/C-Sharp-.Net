﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace KindergartenProject.Application.Models.DTOs
{
    public class ObservationUpdateDto
    {
        public int Id { get; set; } // ObservationNote ID
        public string Note { get; set; } // Öğretmenin girdiği not
        public string Observation { get; set; } // Öğretmenin gözlemi
        public DateTime Date { get; set; } // Gözlem tarihi ve saati
        public int StudentId { get; set; } // İlgili öğrenci ID'si
        public int DevelopmentalAreaId { get; set; } // Gelişim alanı ID'si
    }
}
