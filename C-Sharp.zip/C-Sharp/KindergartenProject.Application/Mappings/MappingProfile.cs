using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.DTOs.DTOs;
using KindergartenProject.Application.Models.VMs;
using KindergartenProject.Application.Models.VMs.VMs;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {


            CreateMap<AppUser, AppUserCreateDto>().ReverseMap();
            CreateMap<AppUser, AppUserViewModel>().ReverseMap();
            CreateMap<AppRole, AppRoleViewModel>().ReverseMap();
            CreateMap<AppRole, AppRoleCreateDto>().ReverseMap();
            CreateMap<AppUser, LoginDto>().ReverseMap();
            
            CreateMap<SchoolAdmin, AppUserListDto>().ReverseMap();
            CreateMap<SchoolAdmin, SchoolAdminCreateDto>().ReverseMap();
            CreateMap<SchoolAdmin, SchoolAdminUpdateDto>().ReverseMap();
            CreateMap<SchoolAdmin, SchoolAdminListDto>().ReverseMap();
            
            CreateMap<Teacher, TeacherCreateDto>().ReverseMap();
            CreateMap<Teacher, AppUserListDto>().ReverseMap();
            CreateMap<Teacher, TeacherListDto>().ReverseMap();
            CreateMap<Teacher, TeacherUpdateDto>().ReverseMap();
            CreateMap<Teacher,TeacherViewModel>().ReverseMap();
            CreateMap<TeacherCreateDto,TeacherViewModel>().ReverseMap();
            CreateMap<TeacherListDto,TeacherViewModel>().ReverseMap();

            CreateMap<Student, StudentCreateDTO>().ReverseMap();
            CreateMap<Student, StudentListDTO>().ReverseMap();
            CreateMap<Student, StudentViewModel>().ReverseMap();
            CreateMap<Student, StudentViewModel>().ReverseMap();
            CreateMap<Student, StudentUpdateDto>().ReverseMap();
            CreateMap<StudentListDTO, StudentViewModel>().ReverseMap();
            
            CreateMap<LoginResponseDto, AppUser>().ReverseMap();

            CreateMap<Classroom, ClassromCreateDto>().ReverseMap();
            CreateMap<Classroom, ClassroomListDto>().ReverseMap();
            CreateMap<Classroom, ClassroomViewModel>().ReverseMap();

            CreateMap<Parent, ParentCreateDto>().ReverseMap();
            CreateMap<Parent, ParentViewModel>().ReverseMap();
            CreateMap<Parent,ParentListDto>().ReverseMap();
            CreateMap<Parent,ParentUpdateDto>().ReverseMap();

            CreateMap<StudentParent,StudentParentCreateDto>().ReverseMap();


            CreateMap<WeeklyMenu,WeeklyMenuCreateDto>().ReverseMap()
             .ForMember(dest => dest.DailyMenus, opt => opt.MapFrom(src => src.DailyMenus));
            CreateMap<DailyMenu,DailyMenuCreateDto>().ReverseMap()
            .ForMember(dest => dest.MenuItems, opt => opt.MapFrom(src => src.MenuItems));
            CreateMap<MenuItemCreateDto, MenuItem>().ReverseMap();  

            CreateMap<WeeklyMenu,WeeklyMenuListDto>().ReverseMap();
            CreateMap<DailyMenu,DailyMenuListDto>().ReverseMap();

            CreateMap<MenuItem,MenuItemListDto>().ReverseMap();

            // Attendance mappings
            //CreateMap<Attendance, MarkAttendanceDto>().ReverseMap();
            CreateMap<Attendance, AttendanceUpdateDto>().ReverseMap();
            CreateMap<Attendance, AttendanceDto>().ReverseMap();
            CreateMap<Attendance, AttendanceCreateDto>().ReverseMap();
            CreateMap<Attendance, AttendanceListViewModel>().ReverseMap();
            CreateMap<Attendance, AttendanceViewModel>().ReverseMap();
            //CreateMap<Attendance, UpdateAttendanceViewModel>().ReverseMap();
            //CreateMap<Attendance, StudentAttendanceDto>().ReverseMap();
            CreateMap<Attendance, StudentAttendanceViewModel>().ReverseMap();

            CreateMap<ObservationNote, ObservationCreateDto>().ReverseMap();
            CreateMap<ObservationNote, ObservationUpdateDto>().ReverseMap();
            CreateMap<ObservationNote, ObservationNoteDto>().ReverseMap();
            CreateMap<DevelopmentalArea, DevelopmentalAreaDto>().ReverseMap();

            CreateMap<WeeklySchedule,WeeklyScheduleCreateDto>().ReverseMap();
            CreateMap<DailySchedule,DailyScheduleCreateDto>().ReverseMap();
            CreateMap<Activity,ActivitiyCreateDto>().ReverseMap();
            
            CreateMap<WeeklySchedule,WeeklyScheduleListDto>().ReverseMap();
        }
    }
}