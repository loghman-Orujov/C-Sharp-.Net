using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Services
{
    public interface IWeeklyMenuService
    {
        Task<WeeklyMenu> Add(WeeklyMenuCreateDto weeklyMenuCreateDTO);
        Task<WeeklyMenuCreateDto> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate);
        Task<IEnumerable<WeeklyMenuListDto>> GetAllWeeklyMenu();
        Task Update(WeeklyMenuListDto weeklyMenuUpdateDto);
      

    }
}