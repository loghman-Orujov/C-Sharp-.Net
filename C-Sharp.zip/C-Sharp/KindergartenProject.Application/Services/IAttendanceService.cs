﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Services
{
    
        public interface IAttendanceService
        {
            Task<Attendance> GetAttendanceByIdAsync(int id);
            Task<IEnumerable<Attendance>> GetAllAttendancesAsync();

            //  Task<IEnumerable<Attendance>> GetAttendancesByStudentIdAsync(int studentId);
            Task<IEnumerable<Attendance>> StudentAttendanceAsync(int studentId);
           Task<IEnumerable<Attendance>> GetAttendancesByClassroomIdAsync(int classroomId);

        // Task<IEnumerable<Attendance>> GetAttendancesByDateAsync(DateTime date);
        Task<IEnumerable<Attendance>> DailyAttendanceAsync(DateTime date);
        // Yoklama işaretleme işlemi
        Task<bool> MarkAttendanceAsync(List<AttendanceDto> attendanceList);


        // Task<bool> UpdateAttendanceAsync(int id, bool isPresent);
        Task<bool> EditAttendanceAsync(int id, bool isPresent);
        //    Task<bool> DeleteAttendanceAsync(int id);
            
        Task IsActive(int id);
        Task<bool> ValidateAttendanceAsync(int studentId, DateTime date);


    }
    }
