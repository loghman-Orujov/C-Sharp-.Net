using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;

namespace KindergartenProject.Application.Services
{
    public interface IClassroomService
    {
        Task Add(ClassromCreateDto classromCreateDto);
        Task<IEnumerable<ClassroomListDto>> GetAll();

        Task Update(ClassroomListDto classroomListDto);
        Task IsActive(int id);
        Task<IEnumerable<ClassroomListDto>> GetClassroomsByTeacherIdAsync(int teacherId);
    }
}