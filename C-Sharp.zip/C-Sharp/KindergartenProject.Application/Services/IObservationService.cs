﻿using KindergartenProject.Application.Models.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Services.Interfaces
{
    public interface IObservationService
    {
        Task CreateObservationNoteAsync(ObservationCreateDto dto);
        Task UpdateObservationNoteAsync(ObservationUpdateDto dto);
        Task DeleteObservationNoteAsync(int id);
        Task<ObservationNoteDto> GetObservationByIdAsync(int id);
        Task<List<ObservationNoteDto>> GetObservationsByStudentIdAsync(int studentId);
    }
}
