﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Services
{
	public interface ISchoolAdminService
	{
		Task Add(SchoolAdminCreateDto schoolAdminCreateDto);
		Task<IEnumerable<SchoolAdminListDto>> GetAll();
		Task Update(SchoolAdminUpdateDto schoolAdminUpdateDto);
		Task IsActive(int id);
		Task<SchoolAdminListDto> GetById(int id);


		//bunlar kullanılıyor mu?
		Task AddTeacherAsync();
		Task RemoveTeacherAsync();
		Task UpdateTeacherAsync();

		Task AddStudentAsync();
		Task RemoveStudentAsync();
		Task UpdateStudentAsync();
		
		Task AddParentAsync();
		Task RemoveParentAsync();
		Task UpdateParentAsync();

		Task CreateClassAsync();
		Task RemoveClassAsync();
		Task UpdateClassAsync();

	}
}
