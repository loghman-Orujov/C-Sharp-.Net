﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.DTOs.DTOs;
using KindergartenProject.Application.Models.VMs.VMs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Services
{
	public interface IAppUserService
	{
		Task<IEnumerable<AppUserListDto>> GetAll();
		Task<LoginResponseDto> Login(LoginDto loginDTO);
		Task<string> GenerateToken(string userId);
	}
}
