using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Services
{
    public interface IWeeklyScheduleService
    {
        Task<WeeklySchedule> Add(WeeklyScheduleCreateDto weeklyScheduleCreateDto);
        Task<WeeklyScheduleCreateDto> GetWeeklyScheduleByDateRange(DateTime startDate, DateTime endDate);
        Task<IEnumerable<WeeklyScheduleListDto>> GetAllWeeklySchedule();
        Task Update(WeeklyScheduleListDto weeklyScheduleUpdateDto);
    }
}