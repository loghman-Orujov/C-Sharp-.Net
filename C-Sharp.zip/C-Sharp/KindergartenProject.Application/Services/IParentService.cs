﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs.DTOs;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Services
{
    public interface IParentService
    {
        Task<int> Add(ParentCreateDto parentCreateDto);
        Task<IEnumerable<ParentListDto>> GetAll();
        Task Update(ParentUpdateDto parentUpdateDto);
        Task IsActive(int id);
    }
}
