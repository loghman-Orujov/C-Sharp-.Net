﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;

namespace KindergartenProject.Application.Services
{
	public interface IStudentService
	{
		Task<int> Add(StudentCreateDTO teacherCreateDto);
		Task<IEnumerable<StudentListDTO>> GetAll();
        Task Update(StudentUpdateDto studentUpdateDto);
        Task IsActive(int id);
        Task<StudentListDTO> GetById(int id);
    }
}
