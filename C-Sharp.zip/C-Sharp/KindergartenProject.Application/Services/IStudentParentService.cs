﻿using KindergartenProject.Application.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Services
{
    public interface IStudentParentService
    {
        Task Add(StudentParentCreateDto studentParentCreateDto);
        //Maybe needed in the future?
        //Task<IEnumerable<StudentParentListDto>> GetAll();
        //Task Update(StudentParentUpdateDto studentParentUpdateDto);
        //Task IsActive(int id);
        //Task<StudentParentListDTO> GetById(int id);
    }
}
