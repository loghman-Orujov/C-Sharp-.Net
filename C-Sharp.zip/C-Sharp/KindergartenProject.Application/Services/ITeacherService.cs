using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.DTOs.DTOs;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Application.Services
{
    public interface ITeacherService
    {
        Task Add(TeacherCreateDto teacherCreateDto);
        Task<IEnumerable<TeacherListDto>> GetAll();
        Task Update(TeacherUpdateDto teacherUpdateDto);
        Task IsActive(int id);
        Task<TeacherCreateDto> GetById(int id);
    }
}