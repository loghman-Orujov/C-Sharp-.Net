using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;

namespace KindergartenProject.Application.Managers
{
    public class WeeklyScheduleManager : IWeeklyScheduleService
    {
        private readonly IWeeklyScheduleRepository _weeklyScheduleRepository;
        private readonly IMapper _mapper;

        public WeeklyScheduleManager(IWeeklyScheduleRepository weeklyScheduleRepository, IMapper mapper)
        {
            _weeklyScheduleRepository = weeklyScheduleRepository;
            _mapper = mapper;
        }

        public async Task<WeeklySchedule> Add(WeeklyScheduleCreateDto weeklyScheduleCreateDto)
        {
            var weeklySchedule = _mapper.Map<WeeklySchedule>(weeklyScheduleCreateDto);

            return await _weeklyScheduleRepository.CreateWeeklySchedule(weeklySchedule);
        }

        public async Task<IEnumerable<WeeklyScheduleListDto>> GetAllWeeklySchedule()
        {
            var weeklyScheduleList = await _weeklyScheduleRepository.GetWeeklyMenuAsync();
            return _mapper.Map<IEnumerable<WeeklyScheduleListDto>>(weeklyScheduleList);
        }

        public async Task<WeeklyScheduleCreateDto> GetWeeklyScheduleByDateRange(DateTime startDate, DateTime endDate)
        {
             var weeklySchedule = await _weeklyScheduleRepository.GetWeeklyMenuByDateRange(startDate, endDate);
            if (weeklySchedule == null)
            {
                return null;
            }
            return _mapper.Map<WeeklyScheduleCreateDto>(weeklySchedule);
        }

        public async Task Update(WeeklyScheduleListDto weeklyScheduleUpdateDto)
        {
             var existingWeeklyMenu = await _weeklyScheduleRepository.GetById(weeklyScheduleUpdateDto.Id);

            if (existingWeeklyMenu != null)
            {
                await _weeklyScheduleRepository.Remove(existingWeeklyMenu);
            }
            var newWeeklySchedule = _mapper.Map<WeeklySchedule>(weeklyScheduleUpdateDto);
            await _weeklyScheduleRepository.AddAsync(newWeeklySchedule);

        }
    }
}