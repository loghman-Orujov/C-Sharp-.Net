﻿using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Managers
{
    public class StudentParentManager : IStudentParentService
    {
        private readonly IStudentParentRepository _studentParentRepository;
        private readonly IMapper _mapper;

        public StudentParentManager(IStudentParentRepository studentParentRepository, IMapper mapper)
        {
            _studentParentRepository = studentParentRepository;
            _mapper = mapper;
        }

        public async Task Add(StudentParentCreateDto studentParentCreateDto)
        {
            if (studentParentCreateDto == null){ throw new ArgumentNullException(nameof(studentParentCreateDto)); }

            var studentParentEntity = _mapper.Map<StudentParent>(studentParentCreateDto);
            await _studentParentRepository.AddAsync(studentParentEntity);
        }
    }
}
