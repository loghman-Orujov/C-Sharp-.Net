﻿using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Managers
{
    public class AttendanceManager : IAttendanceService
    {
        private readonly IAttendanceRepository _attendanceRepository;
    

        public AttendanceManager(IAttendanceRepository attendanceRepository)
        {
            _attendanceRepository = attendanceRepository;
        }

       public async Task<Attendance> GetAttendanceByIdAsync(int id)
{
    return await _attendanceRepository.GetByIdAsync(id);
}

public async Task<IEnumerable<Attendance>> GetAllAttendancesAsync()
{
    return await _attendanceRepository.GetAllAsync();
}

public async Task<IEnumerable<Attendance>> StudentAttendanceAsync(int studentId)
{
    return await _attendanceRepository.StudentAsync(studentId);
}

        public async Task<IEnumerable<Attendance>> GetAttendancesByClassroomIdAsync(int classroomId)
        {
            return await _attendanceRepository.GetByClassroomIdAsync(classroomId);
        }

        public async Task<IEnumerable<Attendance>> DailyAttendanceAsync(DateTime date)
{
    return await _attendanceRepository.DailyAsync(date);
}

        public async Task<bool> MarkAttendanceAsync(List<AttendanceDto> attendanceList)
        {
            foreach (var attendanceDto in attendanceList)
            {
                var attendance = new Attendance
                {
                    StudentId = attendanceDto.StudentId,
                    StudentName = attendanceDto.StudentName,
                    ClassroomId = attendanceDto.ClassroomId,
                    ClassName = attendanceDto.ClassName,
                    Date = attendanceDto.Date,
                    IsPresent = attendanceDto.IsPresent
                };

                // Yoklama veritabanına kaydediliyor.
                await _attendanceRepository.AddAsync(attendance);
            }

            // Tüm değişiklikler kaydediliyor.
           // await _attendanceRepository.SaveChangesAsync();
            return true;
        }

        public async Task<bool> EditAttendanceAsync(int id, bool isPresent)
{
    var attendance = await _attendanceRepository.GetByIdAsync(id);
    if (attendance == null)
    {
        return false;
    }

    attendance.IsPresent = isPresent;
    await _attendanceRepository.EditAsync(attendance);
    return true;
}

      

public async Task<bool> ValidateAttendanceAsync(int studentId, DateTime date)
{
    return !await _attendanceRepository.AttendanceExistsAsync(studentId, date);
}

        public async Task IsActive(int id)
        {
            await _attendanceRepository.IsActiveAsync(id);
        }
    }
}
