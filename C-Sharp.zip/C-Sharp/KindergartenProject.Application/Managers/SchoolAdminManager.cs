﻿using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Managers
{
	public class SchoolAdminManager : ISchoolAdminService
	{
		private readonly ISchoolAdminRepository _schoolAdminRepository;
		private readonly IMapper _mapper;

		public SchoolAdminManager(ISchoolAdminRepository schoolAdminRepository, IMapper mapper)
		{
			_schoolAdminRepository = schoolAdminRepository;
			_mapper = mapper;
		}

		public async Task Add(SchoolAdminCreateDto schoolAdminCreateDto)
		{
			if (schoolAdminCreateDto == null) { throw new ArgumentNullException(nameof(schoolAdminCreateDto)); }

			var schoolAdminEntity = _mapper.Map<SchoolAdmin>(schoolAdminCreateDto);
			schoolAdminEntity.UserRole = "SchoolAdmin";

			await _schoolAdminRepository.AddAsync(schoolAdminEntity);
		}

		public async Task<IEnumerable<SchoolAdminListDto>> GetAll()
		{
			var schoolAdmin = await _schoolAdminRepository.GetAllAsync();
			var filteredAdmins = schoolAdmin.Where(admin => admin.Id != 1).ToList();
			return _mapper.Map<IEnumerable<SchoolAdminListDto>>(filteredAdmins);
		}

		public async Task<SchoolAdminListDto> GetById(int id)
		{
			var schoolAdmin = await _schoolAdminRepository.GetByIdAsync(id);
			if (schoolAdmin == null)
			{
				return null;
			}
			var schoolAdminListDto = _mapper.Map<SchoolAdminListDto>(schoolAdmin);
			return schoolAdminListDto;
		}

		public async Task IsActive(int id)
		{
			await _schoolAdminRepository.IsActiveAsync(id);
		}

		public async Task Update(SchoolAdminUpdateDto schoolAdminUpdateDto)
		{
			var schoolAdminEntity = _mapper.Map<SchoolAdmin>(schoolAdminUpdateDto);
			await _schoolAdminRepository.UpdateAsync(schoolAdminEntity);
		}

		//--------------------------
		//bunlar kullanılıyor mu?
		public Task AddParentAsync()
		{
			throw new NotImplementedException();
		}

		public Task AddSchoolAdminAsync()
		{
			throw new NotImplementedException();
		}

		public Task AddStudentAsync()
		{
			throw new NotImplementedException();
		}

		public Task AddTeacherAsync()
		{
			throw new NotImplementedException();
		}

		public Task CreateClassAsync()
		{
			throw new NotImplementedException();
		}

		

		public Task RemoveClassAsync()
		{
			throw new NotImplementedException();
		}

		public Task RemoveParentAsync()
		{
			throw new NotImplementedException();
		}

		public Task RemoveStudentAsync()
		{
			throw new NotImplementedException();
		}

		public Task RemoveTeacherAsync()
		{
			throw new NotImplementedException();
		}

		public Task UpdateClassAsync()
		{
			throw new NotImplementedException();
		}

		public Task UpdateParentAsync()
		{
			throw new NotImplementedException();
		}

		public Task UpdateStudentAsync()
		{
			throw new NotImplementedException();
		}

		public Task UpdateTeacherAsync()
		{
			throw new NotImplementedException();
		}
	}
}
