﻿using KindergartenProject.Application.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;

namespace KindergartenProject.Application.Managers
{
    public class ParentManager : IParentService
    {
        private readonly IParentRepository _parentRepository; 
        private readonly IMapper _mapper;

          public ParentManager(IParentRepository parentRepository, IMapper mapper)
        {
            _parentRepository = parentRepository;
            _mapper = mapper;
        }

        public async Task<int> Add(ParentCreateDto parentCreateDto)
        {
            if (parentCreateDto == null) { throw new ArgumentNullException(nameof(parentCreateDto)); }

            var parentEntity = _mapper.Map<Parent>(parentCreateDto);
            parentEntity.UserRole = "Parent";
            //eklenen parent'ın Id'sini yakala.
            //Daha sonra StudentParent tablosuna işlemek için API'ye iletmeliyiz
            //API de UI controller'a iletecek ve UI Controller'da StudentParent API'sini çağırıcak
            var parentId = await _parentRepository.AddAsync(parentEntity);

            return parentId;
        }

        public async Task<IEnumerable<ParentListDto>> GetAll()
        {
            var parent = await _parentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<ParentListDto>>(parent);
        }
        public async Task Update(ParentUpdateDto parentUpdateDto)
        {
            var parentEntity = _mapper.Map<Parent>(parentUpdateDto);
            await _parentRepository.UpdateAsync(parentEntity);
        }

        public async Task IsActive(int id)
        {
            await _parentRepository.IsActiveAsync(id);
        }
    }
}
