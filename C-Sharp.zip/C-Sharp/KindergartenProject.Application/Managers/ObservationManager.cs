﻿
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services.Interfaces;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;

namespace KindergartenProject.Application.Services.Implementations
{
    public class ObservationService : IObservationService
    {
        private readonly IObservationRepository _observationRepository;
        private readonly IMapper _mapper;

        public ObservationService(IObservationRepository observationRepository, IMapper mapper)
        {
            _observationRepository = observationRepository;
            _mapper = mapper;
        }

        public async Task CreateObservationNoteAsync(ObservationCreateDto dto)
        {
            var observationNote = _mapper.Map<ObservationNote>(dto);
            await _observationRepository.AddAsync(observationNote);
        }

        public async Task UpdateObservationNoteAsync(ObservationUpdateDto dto)
        {
            var existingNote = await _observationRepository.GetByIdAsync(dto.Id);
            if (existingNote != null)
            {
                existingNote.Note = dto.Note;
                existingNote.Observation = dto.Observation;
                existingNote.Date = dto.Date;
                existingNote.DevelopmentalAreaId = dto.DevelopmentalAreaId;
                existingNote.StudentId = dto.StudentId;
                await _observationRepository.UpdateAsync(existingNote);
            }
        }
        public async Task<ObservationNoteDto> GetObservationByIdAsync(int id)
        {
            var observation = await _observationRepository.GetByIdAsync(id);  // Ensure this method exists in the repository
            return _mapper.Map<ObservationNoteDto>(observation);
        }


        public async Task DeleteObservationNoteAsync(int id)
        {
            var observationNote = await _observationRepository.GetByIdAsync(id);
            if (observationNote != null)
            {
                observationNote.IsActive = false; // Soft delete
                await _observationRepository.UpdateAsync(observationNote);
            }
        }

        public async Task<List<ObservationNoteDto>> GetObservationsByStudentIdAsync(int studentId)
        {
            var observations = await _observationRepository.GetByStudentIdAsync(studentId);
            return _mapper.Map<List<ObservationNoteDto>>(observations);
        }
    }
}
