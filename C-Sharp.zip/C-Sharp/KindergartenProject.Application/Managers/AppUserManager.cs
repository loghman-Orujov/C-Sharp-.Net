﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Models.DTOs.DTOs;
using KindergartenProject.Application.Models.VMs.VMs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace KindergartenProject.Application.Managers
{
	public class AppUserManager : IAppUserService  //isimlendirme olmaz
	{
		private readonly IAppUserRepository _appUserRepository; //neden nesne tipi interface?
		private readonly IMapper _mapper;
		private readonly JwtSettings _jwtSettings;

		public AppUserManager(IAppUserRepository appUserRepository, IMapper mapper,IOptions<JwtSettings> jwtSettings)
		{

			_jwtSettings = jwtSettings.Value;
			_appUserRepository = appUserRepository;
			_mapper = mapper;
		}

		public async Task Add(AppUserCreateDto appUserCreateDto)
		{
			if (appUserCreateDto == null) { throw new ArgumentNullException(nameof(appUserCreateDto)); }

			var user = _mapper.Map<AppUser>(appUserCreateDto);

			await _appUserRepository.AddAsync(user);
		}

         public async Task<string> GenerateToken(string userId)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtSettings.Key);

            var claims = new List<Claim>
         {
        new Claim(JwtRegisteredClaimNames.Sub, userId),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString(), ClaimValueTypes.Integer64)
         };

            var now = DateTime.UtcNow;

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                NotBefore = now, // Token şu andan itibaren geçerli olacak
                Expires = now.AddMinutes(_jwtSettings.DurationInMinutes), // Expires zamanını NotBefore zamanından sonra ayarlayın
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _jwtSettings.Issuer,
                Audience = _jwtSettings.Audience
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }


        public async Task<LoginResponseDto> Login(LoginDto loginDTO)
        {
			var loginEntity=_mapper.Map<AppUser>(loginDTO);
            var user=await _appUserRepository.Login(loginEntity);
			var LoginResponseDto= _mapper.Map<LoginResponseDto>(user);
			return LoginResponseDto;
        }

        public async Task Update(AppUserUpdateDto appUserUpdateDto)
		{
			if (appUserUpdateDto == null) { throw new ArgumentNullException(nameof(appUserUpdateDto)); }

			var user = _mapper.Map<AppUser> (appUserUpdateDto);
			await _appUserRepository.UpdateAsync(user);
		}

        async Task<IEnumerable<AppUserListDto>> IAppUserService.GetAll()
        {
			var users =await _appUserRepository.GetAllAsync();
			return _mapper.Map<IEnumerable<AppUserListDto>>(users);
        }
    }
}
