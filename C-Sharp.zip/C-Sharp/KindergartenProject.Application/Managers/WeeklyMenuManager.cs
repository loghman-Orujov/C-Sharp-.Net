using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;

namespace KindergartenProject.Application.Managers
{
    public class WeeklyMenuManager : IWeeklyMenuService
    {

        private readonly IWeeklyMenuRepository _weeklyMenuRepository;
        private readonly IMapper _mapper;

        public WeeklyMenuManager(IWeeklyMenuRepository weeklyMenuRepository, IMapper mapper)
        {
            _weeklyMenuRepository = weeklyMenuRepository;
            _mapper = mapper;
        }

        public async Task<WeeklyMenu> Add(WeeklyMenuCreateDto weeklyMenuCreateDTO)
        {
            var weeklyMenu = _mapper.Map<WeeklyMenu>(weeklyMenuCreateDTO);

            return await _weeklyMenuRepository.CreateWeekly(weeklyMenu);
        }

        public async Task<IEnumerable<WeeklyMenuListDto>> GetAllWeeklyMenu()
        {
            var weeklyMenuList = await _weeklyMenuRepository.GetWeeklyMenuAsync();
            return _mapper.Map<IEnumerable<WeeklyMenuListDto>>(weeklyMenuList);
        }

        public Task<WeeklyMenu> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<WeeklyMenuCreateDto> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate)
        {
            var weeklyMenu = await _weeklyMenuRepository.GetWeeklyMenuByDateRange(startDate, endDate);
            if (weeklyMenu == null)
            {
                return null;
            }
            return _mapper.Map<WeeklyMenuCreateDto>(weeklyMenu);
        }

        public async Task Update(WeeklyMenuListDto weeklyMenuUpdateDto)
        {
            var existingWeeklyMenu = await _weeklyMenuRepository.GetById(weeklyMenuUpdateDto.id);

            if (existingWeeklyMenu != null)
            {
                await _weeklyMenuRepository.Remove(existingWeeklyMenu);
            }
            var newWeeklyMenu = _mapper.Map<WeeklyMenu>(weeklyMenuUpdateDto);
            await _weeklyMenuRepository.AddAsync(newWeeklyMenu);
           
        }

    }
}

