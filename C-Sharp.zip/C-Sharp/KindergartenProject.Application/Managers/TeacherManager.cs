using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;

namespace KindergartenProject.Application.Managers
{
    public class TeacherManager : ITeacherService
    {
        private readonly ITeacherRepository _teacherRepository;
        private readonly IMapper _mapper;
        
        

        public TeacherManager(ITeacherRepository teacherRepository, IMapper mapper)
        {
            _teacherRepository = teacherRepository;
            _mapper = mapper;
        }
        public async Task Add(TeacherCreateDto teacherCreateDto)
        {
            if (teacherCreateDto == null) { throw new ArgumentNullException(nameof(teacherCreateDto)); }

            var teacherEntity = _mapper.Map<Teacher>(teacherCreateDto);
            teacherEntity.UserRole = "Teacher";

            await _teacherRepository.AddAsync(teacherEntity);
        }


        public async Task<IEnumerable<TeacherListDto>> GetAll()
        {
            var teacher = await _teacherRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<TeacherListDto>>(teacher);
        }

        public async Task<TeacherCreateDto> GetById(int id)
        {

            var teacher = await _teacherRepository.GetByIdAsync(id);
            if (teacher == null)
            {
                return null;
            }
            var teacherDto = _mapper.Map<TeacherCreateDto>(teacher);
            return teacherDto;
        }

        public async Task IsActive(int id)
        {
            await _teacherRepository.IsActiveAsync(id);
        }

        public async Task Update(TeacherUpdateDto teacherUpdateDto)
        {

            if (teacherUpdateDto == null)
            {
                throw new ArgumentNullException(nameof(teacherUpdateDto));
            }


            var existingEntity = await _teacherRepository.GetByIdAsync(teacherUpdateDto.Id);

            if (existingEntity != null)
            {

                existingEntity.UpdatedDate = DateTime.Now;
                var updatedEntity = _mapper.Map(teacherUpdateDto, existingEntity);
                updatedEntity.Password = existingEntity.Password;
                await _teacherRepository.UpdateAsync(updatedEntity);
            }
            else
            {
                throw new Exception("Entity not found");
            }
        }


    }
}