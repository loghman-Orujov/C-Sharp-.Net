using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;

namespace KindergartenProject.Application.Managers
{
    public class ClassroomManager : IClassroomService
    {
        private readonly IClassroomRepository _classroomRepository; //neden nesne tipi interface?
		private readonly IMapper _mapper;

        public ClassroomManager(IClassroomRepository classroomRepository, IMapper mapper)
        {
            _classroomRepository = classroomRepository;
            _mapper = mapper;
        }
        public async Task Add(ClassromCreateDto classromCreateDto)
        {
            if (classromCreateDto == null) { throw new ArgumentNullException(nameof(classromCreateDto)); }

            var classroom = _mapper.Map<Classroom>(classromCreateDto);


            await _classroomRepository.AddAsync(classroom);
        }

        public async Task<IEnumerable<ClassroomListDto>> GetAll()
        {
            var classrooms = await _classroomRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<ClassroomListDto>>(classrooms);
        }

        public async Task IsActive(int id)
        {
           await _classroomRepository.IsActiveAsync(id);
        }

        public  async Task Update(ClassroomListDto classroomListDto)
        {
            var classroom = _mapper.Map<Classroom>(classroomListDto);

            await _classroomRepository.UpdateAsync(classroom);
        }
        public async Task<IEnumerable<ClassroomListDto>> GetClassroomsByTeacherIdAsync(int teacherId)
        {
            var classrooms = await _classroomRepository.GetClassroomsByTeacherIdAsync(teacherId);
            return _mapper.Map<IEnumerable<ClassroomListDto>>(classrooms);
        }
    }
}