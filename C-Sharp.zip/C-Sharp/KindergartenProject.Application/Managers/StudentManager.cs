﻿using AutoMapper;
using KindergartenProject.Application.Models.DTOs;
using KindergartenProject.Application.Services;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Application.Managers
{
	public class StudentManager : IStudentService
	{
		private readonly IStudentRepository _studentRepository;
		private readonly IMapper _mapper;

		public StudentManager(IStudentRepository studentRepository, IMapper mapper)
		{
			_studentRepository = studentRepository;
			_mapper = mapper;
		}

		public async Task<int> Add(StudentCreateDTO studentCreateDTO)
		{
			if (studentCreateDTO == null) { throw new ArgumentNullException(nameof(studentCreateDTO)); }

			var studentEntity = _mapper.Map<Student>(studentCreateDTO);
            //eklenen student'ın StudentId'sini yakala.
            //Daha sonra StudentParent tablosuna işlemek için API'ye iletmeliyiz
            //API de UI controller'a iletecek ve UI Controller'da StudentParent API'sini çağırıcak
            var studentId = await _studentRepository.AddAsync(studentEntity);

            return studentId;
        }

		public async Task<IEnumerable<StudentListDTO>> GetAll()
        {
            var student = await _studentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<StudentListDTO>>(student);
        }

        public async Task Update(StudentUpdateDto studentUpdateDto)
        {
            var studentEntity = _mapper.Map<Student>(studentUpdateDto);
            await _studentRepository.UpdateAsync(studentEntity);
        }

        public async Task<StudentListDTO> GetById(int id)
        {

            var student = await _studentRepository.GetByIdAsync(id);
            if (student == null)
            {
                return null;
            }
            var studentListDto = _mapper.Map<StudentListDTO>(student);
            return studentListDto;
        }

        public async Task IsActive(int id)
        {
            await _studentRepository.IsActiveAsync(id);
        }
    }
}
