﻿using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class AttendanceConfig : IEntityTypeConfiguration<Attendance>
    {
        public void Configure(EntityTypeBuilder<Attendance> builder)
        {
           
            //builder.ToTable("Attendances"); // AppDbContext'te isimlendirme yapılmış.

            builder.HasKey(a => a.Id);

            builder.Property(a => a.StudentId)
                .IsRequired();

            builder.Property(a => a.ClassroomId)
                .IsRequired();

            builder.Property(a => a.StudentName)
               .IsRequired();

            builder.Property(a => a.ClassName)
                .IsRequired();

            builder.Property(a => a.Date)
                .IsRequired();

            builder.Property(a => a.IsPresent)
                .IsRequired();

            builder.HasOne(a => a.Student)
                .WithMany(s => s.Attendances) // Student varlığının Attendances koleksiyonu ile ilişkilidir
                .HasForeignKey(a => a.StudentId)
                .OnDelete(DeleteBehavior.NoAction); // Varsayılan davranış: Student silinirse Attendance da silinir

            builder.HasOne(a => a.Classroom)
                .WithMany(c => c.Attendances) // Classroom varlığının Attendances koleksiyonu ile ilişkilidir
                .HasForeignKey(a => a.ClassroomId)
                .OnDelete(DeleteBehavior.NoAction); // Varsayılan davranış: Classroom silinirse Attendance da silinir*/
        }
    }
}
