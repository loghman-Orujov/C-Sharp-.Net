using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
   public abstract class BaseEntityConfig<TEntity> : IEntityTypeConfiguration<TEntity> where TEntity : class, IBaseEntity
{
    public virtual void Configure(EntityTypeBuilder<TEntity> builder)
    {
        builder.Property(e => e.CreatedDate)
               .HasColumnType("datetime");

        builder.Property(e => e.UpdatedDate)
               .HasColumnType("datetime");

        builder.Property(e => e.DeletedDate)
               .HasColumnType("datetime");
        
    }
}
}