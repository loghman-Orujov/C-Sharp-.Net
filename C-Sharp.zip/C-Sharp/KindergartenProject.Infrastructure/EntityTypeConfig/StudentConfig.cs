﻿using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class StudentConfig : BaseEntityConfig<Student>
	{
		public void Configure(EntityTypeBuilder<Student> builder) //override yazılacak mı?
		{
            builder.HasKey(u => u.StudentId);

            builder.Property(u => u.FirstName)
                .HasMaxLength(30)
                .IsRequired();

            builder.Property(u => u.LastName)
                .HasMaxLength(30)
                .IsRequired();

            builder.Property(u => u.Gender)
                .HasMaxLength(30)
                .IsRequired();

            builder.Property(u => u.Age)
                .IsRequired();

            builder.Property(u => u.SchoolNo)
                .IsRequired();

            builder.Property(u => u.Allergies)
                .HasMaxLength(500);

            builder.Property(u => u.Diseases)
                .HasMaxLength(500);

            builder.Property(u => u.BloodType)
                .HasMaxLength(15)
                .IsRequired();

            builder.Property(u => u.Medications)
                .HasMaxLength(500);

            builder.Property(u => u.DietNotes)
                .HasMaxLength(500);

            builder.Property(u => u.EmergencyContact)
                .HasMaxLength(500)
                .IsRequired();

            builder.Property(u => u.IsActive)
                .IsRequired()
                .HasDefaultValue(true);

            builder.HasOne(s => s.Classroom) // Student has one Classroom
                .WithMany(c => c.Students) // Classroom has many Students
                .HasForeignKey(s => s.ClassroomId)
                .OnDelete(DeleteBehavior.Cascade);

			builder.HasMany(s => s.StudentParents)
				.WithOne(sp => sp.Student)
				.HasForeignKey(sp => sp.StudentId);
		}
    }
}
