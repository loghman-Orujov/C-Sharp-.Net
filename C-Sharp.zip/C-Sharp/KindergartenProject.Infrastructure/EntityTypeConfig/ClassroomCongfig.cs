using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class ClassroomCongfig : BaseEntityConfig<Classroom>
    {
        public void Configure(EntityTypeBuilder<Classroom> builder)
        {
            builder.HasKey(u => u.ClassroomId);

            builder.Property(u => u.ClassName)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(u=>u.Capacity)
                    .IsRequired();
            builder.Property(u => u.TeacherId)
                    .IsRequired();
            builder.Property(u => u.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);

             builder.HasMany(c => c.Students) // A Classroom has many Students
                   .WithOne(s => s.Classroom) // Each Student is related to one Classroom
                   .HasForeignKey(s => s.ClassroomId) // Foreign key in Student entity
                   .OnDelete(DeleteBehavior.NoAction);

            /*builder.HasOne(c => c.Teacher)
                .WithOne(x => x.Classroom)
                .HasForeignKey<Classroom>(c => c.TeacherId)
                .OnDelete(DeleteBehavior.NoAction);*/

            base.Configure(builder);
        }
    }
}