using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class WeeklyMenuConfig : BaseEntityConfig<WeeklyMenu>
    {
        public void Configure(EntityTypeBuilder<WeeklyMenu> builder)
        {

            builder.HasKey(wm => wm.Id);

            builder.Property(wm => wm.WeekStartDate)
                .IsRequired();


            builder.HasMany(wm => wm.DailyMenus)
                .WithOne(dm => dm.WeeklyMenu)
                .HasForeignKey(dm => dm.WeeklyMenuId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}