﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using KindergartenProject.Domain.Entities;


namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
	public class ParentConfig : BaseEntityConfig<Parent>
	{
		public void Configure(EntityTypeBuilder<Parent> builder)
		{
			builder.HasKey(u => u.Id);

			builder.Property(u => u.FirstName)
				   .IsRequired()
				   .HasMaxLength(50);

			builder.Property(u => u.LastName)
				   .IsRequired()
				   .HasMaxLength(50);

			builder.Property(u => u.Gender)
				   .IsRequired()
				   .HasMaxLength(10);

			builder.Property(u => u.UserRole)
				   .IsRequired();

			builder.Property(u => u.Occupation)
			.HasMaxLength(100);

			builder.HasMany(s => s.StudentParents)
				.WithOne(sp => sp.Parent)
				.HasForeignKey(sp => sp.ParentId);
		}
	}
}
