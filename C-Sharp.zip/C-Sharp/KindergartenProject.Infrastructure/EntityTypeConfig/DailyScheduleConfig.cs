using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{

    public class DailyScheduleConfig :BaseEntityConfig<DailySchedule>
    {
        public void Configure(EntityTypeBuilder<DailySchedule> builder)
        {
            builder.HasKey(ds=> ds.Id);

            builder.Property(ds => ds.DayOfWeek)
                .IsRequired();

             builder.HasOne(dm => dm.WeeklySchedule)
                .WithMany(wm => wm.DailySchedules)
                .HasForeignKey(dm => dm.WeeklyScheduleId);
        }
    }
    
}