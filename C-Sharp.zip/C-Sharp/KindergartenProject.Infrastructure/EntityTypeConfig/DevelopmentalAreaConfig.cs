﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class DevelopmentalAreaConfig : BaseEntityConfig<DevelopmentalArea>
    { 
        public void Configure(EntityTypeBuilder<DevelopmentalArea> builder)
        {
          builder.HasKey(da => da.Id);
          builder.Property(da => da.Name).IsRequired().HasMaxLength(100);
          builder.HasMany(da => da.ObservationNotes)
               .WithOne(on => on.DevelopmentalArea)
               .HasForeignKey(on => on.DevelopmentalAreaId)
               .OnDelete(DeleteBehavior.Cascade);
        }
}
}
