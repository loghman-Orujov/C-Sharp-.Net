﻿using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class ObservationNoteConfig : BaseEntityConfig<ObservationNote>
    {
        public void Configure(EntityTypeBuilder<ObservationNote> builder)
        {
            builder.HasKey(on => on.Id);
            builder.Property(on => on.Note).IsRequired();
            builder.Property(on => on.Observation).IsRequired();
            builder.Property(on => on.Date).IsRequired();

            builder.HasOne(on => on.Student)
                   .WithMany(s => s.ObservationNotes)
                   .HasForeignKey(on => on.StudentId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(on => on.DevelopmentalArea)
                   .WithMany(da => da.ObservationNotes)
                   .HasForeignKey(on => on.DevelopmentalAreaId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
