using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class MenuItemConfig:BaseEntityConfig<MenuItem>
    {
        public void Configure(EntityTypeBuilder<MenuItem> builder)
        {
            builder.HasKey(dm => dm.Id);

            builder.Property(dm => dm.Calories)
                .IsRequired();

            builder.Property(dm => dm.ItemDescription)
                .IsRequired()
                .HasMaxLength(500);

            builder.Property(dm => dm.ItemName)
                .IsRequired()
                .HasMaxLength(500);

            builder.HasOne(dm => dm.DailyMenu)
                .WithMany(mi => mi.MenuItems)
                .HasForeignKey(dm => dm.DailyMenuId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
