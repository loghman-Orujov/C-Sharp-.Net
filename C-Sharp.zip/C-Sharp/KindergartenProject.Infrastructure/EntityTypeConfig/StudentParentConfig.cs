﻿using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class StudentParentConfig : BaseEntityConfig<StudentParent>
    {
        public void Configure (EntityTypeBuilder<StudentParent> builder) 
        {
            builder.HasKey(sp => sp.StudentParentId);

            builder.HasOne(sp => sp.Student)
                .WithMany(s => s.StudentParents)
                .HasForeignKey(sp => sp.StudentId)
            .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(sp => sp.Parent)
                .WithMany(p => p.StudentParents)
                .HasForeignKey(sp => sp.ParentId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
