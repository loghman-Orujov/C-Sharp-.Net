using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class SchoolAdminConfig : BaseEntityConfig<SchoolAdmin>
    {

        public void Configure(EntityTypeBuilder<SchoolAdmin> builder)
        {
            builder.HasKey(u=>u.Id);    

            builder.Property(u => u.FirstName)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(u => u.LastName)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(u => u.Gender)
                   .IsRequired()
                   .HasMaxLength(10);

            builder.Property(u => u.UserRole)
                   .IsRequired();

            builder.Property(u => u.Address)
                    .IsRequired()
                    .HasMaxLength(40);

       
        }
    }
}