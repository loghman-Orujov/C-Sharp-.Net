using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class DailyMenuConfig : BaseEntityConfig<DailyMenu>
    {
        public void Configure(EntityTypeBuilder<DailyMenu> builder)
        {
            builder.HasKey(dm => dm.Id);

            builder.Property(dm => dm.DayOfWeek)
                .IsRequired();


            builder.HasOne(dm => dm.WeeklyMenu)
                .WithMany(wm => wm.DailyMenus)
                .HasForeignKey(dm => dm.WeeklyMenuId)
                .OnDelete(DeleteBehavior.NoAction);
        }

    }
}