using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
       public class TeacherConfig : BaseEntityConfig<Teacher>
       {
              public void Configure(EntityTypeBuilder<Teacher> builder)
              {
                     builder.HasKey(u => u.Id);

                     builder.Property(u => u.FirstName)
                            .IsRequired()
                            .HasMaxLength(50);

                     builder.Property(u => u.Password)
                           .IsRequired()
                           .HasMaxLength(10);

                     builder.Property(u => u.LastName)
                            .IsRequired()
                            .HasMaxLength(50);

                     builder.Property(u => u.Gender)
                            .IsRequired()
                            .HasMaxLength(10);

                     builder.Property(u => u.UserRole)
                            .IsRequired();

                     builder.Property(u => u.SubjectSpecialization)
                             .HasMaxLength(20);

                     builder.Property(u => u.IsActive)
                            .IsRequired();

                     base.Configure(builder);
              }
       }
}