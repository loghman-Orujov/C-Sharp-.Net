using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class AppUserConfig : BaseEntityConfig<AppUser>
{
    public void Configure(EntityTypeBuilder<AppUser> builder)
    {
         builder.HasKey(u=>u.Id);   

        builder.Property(u => u.FirstName)
               .IsRequired()
               .HasMaxLength(50);

        builder.Property(u => u.LastName)
               .IsRequired()
               .HasMaxLength(50);

        builder.Property(u => u.Gender)
               .IsRequired()
               .HasMaxLength(10); 
               
       builder.Property(u => u.Password)
                   .IsRequired()
                   .HasMaxLength(10);

        builder.Property(u => u.UserRole)
               .IsRequired()
               .HasConversion<int>(); 

         builder.Property(u => u.IsActive)
               .IsRequired()
               .HasDefaultValue(true);
    }
}
}