using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class ActivitiesConfig : BaseEntityConfig<Activity>
    {
        public void Configure(EntityTypeBuilder<Activity> builder)
        {
           builder.HasKey(a => a.Id);

            builder.Property(a => a.Name)
                .IsRequired()
                .HasMaxLength(200);

            builder.Property(a => a.Description)
                .HasMaxLength(500);

            builder.Property(a => a.StartTime)
                .IsRequired();

            builder.Property(a => a.EndTime)
                .IsRequired();

            builder.HasOne(a => a.DailySchedule)
                .WithMany(ds => ds.Activities)
                .HasForeignKey(a => a.DailyScheduleId);
        }
    }
}