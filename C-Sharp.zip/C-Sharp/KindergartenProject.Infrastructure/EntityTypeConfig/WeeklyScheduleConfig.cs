using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace KindergartenProject.Infrastructure.EntityTypeConfig
{
    public class WeeklyScheduleConfig :BaseEntityConfig<WeeklySchedule>
    {
        public void Configure(EntityTypeBuilder<WeeklySchedule> builder)
        {
            builder.HasKey(ws=> ws.Id);

            builder.Property(ws => ws.StartDate)
                .IsRequired();

            builder.Property(ws => ws.EndDate)
                .IsRequired();

            builder.HasMany(ws => ws.DailySchedules)
                .WithOne(ds => ds.WeeklySchedule)
                .HasForeignKey(ds => ds.WeeklyScheduleId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}