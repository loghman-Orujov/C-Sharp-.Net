using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Infrastructure.EntityTypeConfig;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace KindergartenProject.Infrastructure.Data
{
    public class AppDbContext : IdentityDbContext<AppUser, AppRole, int>//burda neden bunu yaptık ?
    {
        public AppDbContext() { }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<AppUser> AppUsers { get; set; }
        public DbSet<AppRole> AppRoles { get; set; }
        public DbSet<SchoolAdmin> SchoolAdmins { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Parent> Parents { get; set; }
        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<WeeklyMenu> WeeklyMenus { get; set; }
        public DbSet<DailyMenu> DailyMenus { get; set; }
        public DbSet<MenuItem> MenuItems { get; set; }
        public DbSet<StudentParent> StudentParents { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<WeeklySchedule> WeeklySchedules { get; set; }
        public DbSet<DailySchedule> DailySchedules { get; set; }
        public DbSet<Activity> Activities { get; set; }
        public DbSet<ObservationNote> ObservationNotes { get; set; }
        public DbSet<DevelopmentalArea> DevelopmentalAreas { get; set; }





        // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        // {
        //     optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=KindergartenTalha;Trusted_Connection=True;TrustServerCertificate=True");
        //     base.OnConfiguring(optionsBuilder);
        // }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=Kindergarten;Trusted_Connection=True;; TrustServerCertificate=True;");
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.Entity<AppRole>().ToTable("AppRoles");
            builder.Entity<SchoolAdmin>().ToTable("SchoolAdmins");
            builder.Entity<Teacher>().ToTable("Teachers");
            builder.Entity<Student>().ToTable("Students");
            builder.Entity<Parent>().ToTable("Parents");
            builder.Entity<Classroom>().ToTable("Classrooms");
            builder.Entity<WeeklyMenu>().ToTable("WeeklyMenus");
            builder.Entity<DailyMenu>().ToTable("DailyMenus");
            builder.Entity<MenuItem>().ToTable("MenuItems");
            builder.Entity<StudentParent>().ToTable("StudentParents");
            builder.Entity<WeeklySchedule>().ToTable("WeeklySchedules");
            builder.Entity<DailySchedule>().ToTable("DailySchedules");
            builder.Entity<Activity>().ToTable("Activities");
            builder.Entity<Attendance>().ToTable("Attendances");


            builder.ApplyConfiguration(new AppUserConfig());
            builder.ApplyConfiguration(new AppRoleConfig());
            builder.ApplyConfiguration(new SchoolAdminConfig());
            builder.ApplyConfiguration(new TeacherConfig());
            builder.ApplyConfiguration(new StudentConfig());
            builder.ApplyConfiguration(new ParentConfig());
            builder.ApplyConfiguration(new ClassroomCongfig());
            builder.ApplyConfiguration(new WeeklyMenuConfig());
            builder.ApplyConfiguration(new DailyMenuConfig());
            builder.ApplyConfiguration(new MenuItemConfig());
            builder.ApplyConfiguration(new StudentParentConfig());
            builder.ApplyConfiguration(new WeeklyScheduleConfig());
            builder.ApplyConfiguration(new DailyScheduleConfig());
            builder.ApplyConfiguration(new ActivitiesConfig());
            builder.ApplyConfiguration(new AttendanceConfig());

            base.OnModelCreating(builder);



            builder.Entity<SchoolAdmin>().HasData(
                new SchoolAdmin
                {
                    Id = 1,
                    FirstName = "Lokman",
                    LastName = "Hekim",
                    Gender = "Erkek",
                    UserRole = "SchoolAdmin",
                    Address = "yenimahalle 1535.sk",
                    Email = "ferenbulbul@gmail.com",
                    Password = "1234",
                    PhoneNumber = "05415704552"
                }
            );
        }
    }


}