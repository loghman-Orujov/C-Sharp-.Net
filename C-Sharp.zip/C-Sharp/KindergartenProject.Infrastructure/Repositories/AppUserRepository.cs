
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class AppUserRepository : BaseRepository<AppUser>, IAppUserRepository
    {
        public AppUserRepository(AppDbContext context) : base(context) { }

        public async Task<AppUser> Login(AppUser appUser)
        {
            return await _context.AppUsers.FirstOrDefaultAsync(x=>x.Email==appUser.Email && x.Password==appUser.Password);
            //return  _context.AppUsers.Any(x=>x.Email==appUser.Email && x.Password==appUser.Password);
        }

        // farklı metodlar eklenebilira
    }
}