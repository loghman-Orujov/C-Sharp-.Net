using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class WeeklyScheduleRepository : BaseRepository<WeeklySchedule>, IWeeklyScheduleRepository
    {
        public WeeklyScheduleRepository(AppDbContext context) : base(context)
        {
        }

        public  async Task AddAsync<T>(T entity) where T : class
        {
             await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<WeeklySchedule> CreateWeeklySchedule(WeeklySchedule weeklySchedule)
        {
            await _context.WeeklySchedules.AddAsync(weeklySchedule);
            await _context.SaveChangesAsync();
            return weeklySchedule;
        }

        public async Task<WeeklySchedule> GetById(int id)
        {
            var existingWeeklySchedule = await _context.WeeklySchedules
                .Include(wm => wm.DailySchedules)
                    .ThenInclude(dm => dm.Activities)
                .FirstOrDefaultAsync(wm => wm.Id == id);

            return existingWeeklySchedule;
        }

        public async Task<IEnumerable<WeeklySchedule>> GetWeeklyMenuAsync()
        {
            var weeklySchedule = await _context.WeeklySchedules
                .Include(wm => wm.DailySchedules)
                    .ThenInclude(dm => dm.Activities)
                .ToListAsync();

            return weeklySchedule;
        }

        public async Task<WeeklySchedule> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate)
        {
            var weeklySchedule = await _context.WeeklySchedules
                .Include(ws => ws.DailySchedules)
                    .ThenInclude(ds => ds.Activities)
                .FirstOrDefaultAsync(wm => wm.StartDate.Date == startDate.Date && wm.EndDate.Date == endDate.Date);


            if (weeklySchedule != null)
            {
                foreach (var dailySchedules in weeklySchedule.DailySchedules)
                {
                    Console.WriteLine($"Day: {dailySchedules.DayOfWeek}, Activities Count: {dailySchedules.Activities.Count}");
                }
            }
            else
            {
                Console.WriteLine("No weekly Schedules found for the specified dates.");
            }
            return weeklySchedule;
        }

        public async Task Remove<T>(T entity) where T : class
        {
            _context.Set<T>().Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}