﻿using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.Repositories
{
	public class StudentRepository : BaseRepository<Student>, IStudentRepository
	{
		protected new readonly AppDbContext _context;
		private DbSet<Student> _entities;
		public StudentRepository(AppDbContext context) : base(context)
		{
			_context = context;
			_entities = _context.Set<Student>();
		}

        public new async Task UpdateAsync(Student updatedStudent)
        {
            var existingEntity = await _entities.FindAsync(updatedStudent.StudentId);

            if (existingEntity != null)
            {
                existingEntity.UpdatedDate = DateTime.Now;
                var entry = _context.Entry(existingEntity);

                entry.CurrentValues.SetValues(updatedStudent);

                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Bahsedilen Student Entity'si bulunamadı");
            }
        }
    }
}
