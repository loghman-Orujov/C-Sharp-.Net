﻿using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class StudentParentRepository : BaseRepository<StudentParent>, IStudentParentRepository
    {
        protected new readonly AppDbContext _context;
        private DbSet<StudentParent> _entities;

        public StudentParentRepository(AppDbContext context) : base(context)
        {
            _context = context;
            _entities = _context.Set<StudentParent>();
        }

        //StudentParent relationship table only uses addAsync from the BaseRepository for now.
    }
}
