using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class ClassroomRepository:BaseRepository<Classroom>,IClassroomRepository
    {

        public ClassroomRepository(AppDbContext context) : base(context) { }

        public async Task<IEnumerable<Classroom>> GetClassroomsByTeacherIdAsync(int teacherId)
        {
            return await _context.Classrooms
                .Include(c => c.Teacher)
                .Where(c => c.TeacherId == teacherId)
                .ToListAsync();
        }
    }
}