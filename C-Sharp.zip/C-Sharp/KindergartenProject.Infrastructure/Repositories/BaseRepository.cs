using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Infrastructure.Data;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class, IBaseEntity
    {
        protected readonly AppDbContext _context;
        private DbSet<T> _entities;

        public BaseRepository(AppDbContext context)
        {
            _context = context;
            _entities = _context.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _entities.Where(e => e.IsActive == true).ToListAsync();
        }

        public async Task<T> GetByIdAsync(int id)
        {
            return await _entities.FindAsync(id);
        }

        public async Task<int> AddAsync(T entity)
        {
            await _entities.AddAsync(entity);
            entity.CreatedDate=DateTime.Now;
            await _context.SaveChangesAsync();

            //Eklenen student ise "StudentId" yi yakala, de�ilse "Id" yi yakala
            //AddAsync kullanarak eklenen her entitynin Id de�i�ken ismi buraya eklenmeli
            var idProperty = entity.GetType().GetProperty("Id") 
                ?? entity.GetType().GetProperty("StudentId")
                ?? entity.GetType().GetProperty("ClassroomId")
                ?? entity.GetType().GetProperty("StudentParentId");
            if (idProperty != null)
            {
                return (int)idProperty.GetValue(entity);
            }

            throw new InvalidOperationException("Entity'nin Id veya StudentId veya ClassroomId isminde bir attribute'u yok!" +
                " E�er eklemeye �al��t���n�z entity Repository'sinde BaseRepository'den gelen AddAsync fonksiyonunu kullan�yorsa" +
                " l�tfen BaseRepository.cs dosyas�nda AddAsync i�ine entity'nizin Id de�i�keninin ad�n� yaz�n.");
        }

        public async Task UpdateAsync(T entity)
        {

            entity.UpdatedDate=DateTime.Now;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }



        public async Task IsActiveAsync(int id)
        {
            var entity = await _entities.FindAsync(id);

            if (entity != null)
            {
                entity.IsActive = false;
                entity.DeletedDate=DateTime.Now;
                _context.Entry(entity).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Entity not found");
            }
        }
    }
}
