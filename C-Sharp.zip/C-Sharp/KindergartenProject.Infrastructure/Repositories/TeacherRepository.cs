using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class TeacherRepository:BaseRepository<Teacher>,ITeacherRepository
    {

        protected new readonly AppDbContext _context;
        private DbSet<Teacher> _entities;

        public TeacherRepository(AppDbContext context) :base(context){ 
            _context = context;
            _entities = _context.Set<Teacher>();
        }
        
         public new async Task UpdateAsync(Teacher teacher)
        {
            _entities.Update(teacher);
            await _context.SaveChangesAsync();
        }


    }
}