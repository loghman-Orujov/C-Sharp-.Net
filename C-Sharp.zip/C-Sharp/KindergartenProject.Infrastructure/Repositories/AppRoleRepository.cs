using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class AppRoleRepository : BaseRepository<AppRole>, IAppRoleRepository
    {
        public AppRoleRepository(AppDbContext context) : base(context) { }

        // Özelleştirilmiş yöntemler
        public async Task<AppRole> GetByNameAsync(string roleName)
        {
            return await _context.AppRoles.FirstOrDefaultAsync(r => r.Name == roleName);
        }
    }
}