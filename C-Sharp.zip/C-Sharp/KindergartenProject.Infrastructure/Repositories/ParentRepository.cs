﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;


namespace KindergartenProject.Infrastructure.Repositories
{
    public class ParentRepository : BaseRepository<Parent> ,IParentRepository
    {
          protected new readonly AppDbContext _context;
        private DbSet<Parent> _entities;

        public ParentRepository(AppDbContext context) :base(context){ 
            _context = context;
            _entities = _context.Set<Parent>();
        }
        
         public new async Task UpdateAsync(Parent parent)
        {
            var existingEntity = await _entities.FindAsync(parent.Id);

            if (existingEntity != null)
            {
                
                existingEntity.UpdatedDate=DateTime.Now;
                var entry = _context.Entry(existingEntity);

                entry.CurrentValues.SetValues(parent);

                if (entry.Property(e => e.Password).CurrentValue == null)
                {
                    entry.Property(e => e.Password).IsModified = false;
                }

                entry.Property(e=>e.UserRole).IsModified=false;
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Entity not found");
            }
        }
    }
}
