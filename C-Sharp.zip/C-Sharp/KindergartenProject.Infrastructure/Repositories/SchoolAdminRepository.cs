using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class SchoolAdminRepository:BaseRepository<SchoolAdmin>,ISchoolAdminRepository
    {
		protected new readonly AppDbContext _context;
		private DbSet<SchoolAdmin> _entities;

		public SchoolAdminRepository(AppDbContext context) : base(context)
		{
			_context = context;
			_entities = _context.Set<SchoolAdmin>();
		}

		public new async Task UpdateAsync(SchoolAdmin schoolAdmin)
		{
			var existingEntity = await _entities.FindAsync(schoolAdmin.Id);

			if (existingEntity != null)
			{
				existingEntity.UpdatedDate = DateTime.Now;
				var entry = _context.Entry(existingEntity);

				entry.CurrentValues.SetValues(schoolAdmin);

				if (entry.Property(e => e.Password).CurrentValue == null)
				{
					entry.Property(e => e.Password).IsModified = false;
				}

				await _context.SaveChangesAsync();
			}
			else
			{
				throw new Exception("SchoolAdminRepository Hatas�: School Admin entity'si bulunamad�.");
			}
		}
	}
}