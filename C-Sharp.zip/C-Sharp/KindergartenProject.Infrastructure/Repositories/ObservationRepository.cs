﻿using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Domain.Repositories;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class ObservationRepository : BaseRepository<ObservationNote>, IObservationRepository
    {
        private readonly AppDbContext _context;

        public ObservationRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task<List<ObservationNote>> GetByStudentIdAsync(int studentId)
        {
            return await _context.ObservationNotes
                .Where(o => o.StudentId == studentId && o.IsActive)
                .Include(o => o.DevelopmentalArea) // Include DevelopmentalArea to have access to the associated area details
                .ToListAsync();
        }
    }
}
