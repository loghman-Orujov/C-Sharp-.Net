﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class AttendanceRepository : BaseRepository<Attendance>, IAttendanceRepository
    {
        protected readonly AppDbContext _context;
        private DbSet<Attendance> _entities;

        public AttendanceRepository(AppDbContext context) : base(context)
        {
            _context = context;
            _entities = _context.Set<Attendance>();
        }

        public async Task<bool> AttendanceExistsAsync(int studentId, DateTime date)
        {
            return await _context.Attendances
                .AnyAsync(a => a.StudentId == studentId && a.Date.Date == date.Date);

        }

        // Delete değil de Base'de bulunan IsActive metodunu kullanalım. Base'de o işlemler yapılmış hepsi için aynı.
        // public async Task DeleteAsync(int id)
        // {
        //     var attendance = await GetByIdAsync(id);
        //     if (attendance != null)
        //     {
        //         _context.Attendances.Remove(attendance);
        //         await _context.SaveChangesAsync();
        //     }

        // } 

        public async Task<IEnumerable<Attendance>> GetAllAsync()
        {
            return await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Classroom)
                .ToListAsync();
        }

        public async Task<IEnumerable<Attendance>> GetByClassroomIdAsync(int classroomId)
        {
            return await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Classroom)
                .Where(a => a.ClassroomId == classroomId)
                .ToListAsync();
        }

        public async Task<IEnumerable<Attendance>> DailyAsync(DateTime date)
        {
            return await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Classroom)
                .Where(a => a.Date.Date == date.Date)
                .ToListAsync();
        }

        public async Task<Attendance> GetByIdAsync(int id)
        {
            return await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Classroom)
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<IEnumerable<Attendance>> StudentAsync(int studentId)
        {
            return await _context.Attendances
                .Include(a => a.Student)
                .Include(a => a.Classroom)
                .Where(a => a.StudentId == studentId)
                .ToListAsync();
        }
        public async Task<bool> EditAsync(Attendance attendance)
        {
            var existingAttendance = await _context.Set<Attendance>()
                .FindAsync(attendance.Id);

            if (existingAttendance == null)
            {
                return false;
            }

            // Güncellenmiş alanları mevcut yoklama kaydına kopyala
            existingAttendance.IsPresent = attendance.IsPresent;
            existingAttendance.Date = attendance.Date;
            existingAttendance.ClassroomId = attendance.ClassroomId;
            existingAttendance.StudentId = attendance.StudentId;

            _context.Set<Attendance>().Update(existingAttendance);

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }


        public Task IsActiveAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}