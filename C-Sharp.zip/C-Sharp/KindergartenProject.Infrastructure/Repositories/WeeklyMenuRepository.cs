using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using KindergartenProject.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;

namespace KindergartenProject.Infrastructure.Repositories
{
    public class WeeklyMenuRepository : BaseRepository<WeeklyMenu>, IWeeklyMenuRepository
    {
        public WeeklyMenuRepository(AppDbContext context) : base(context)
        {
        }

        public async Task<WeeklyMenu> CreateWeekly(WeeklyMenu weeklyMenu)
        {
            await _context.WeeklyMenus.AddAsync(weeklyMenu);
            await _context.SaveChangesAsync();
            return weeklyMenu;
        }


        public async Task<WeeklyMenu> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate)
        {
            var weeklyMenu = await _context.WeeklyMenus
                .Include(wm => wm.DailyMenus)
                    .ThenInclude(dm => dm.MenuItems)
                .FirstOrDefaultAsync(wm => wm.WeekStartDate.Date == startDate.Date && wm.WeekEndDate.Date == endDate.Date);
            if (weeklyMenu != null)
            {
                foreach (var dailyMenu in weeklyMenu.DailyMenus)
                {
                    Console.WriteLine($"Day: {dailyMenu.DayOfWeek}, MenuItems Count: {dailyMenu.MenuItems.Count}");
                }
            }
            else
            {
                Console.WriteLine("No weekly menu found for the specified dates.");
            }
            return weeklyMenu;
        }

        public async Task<IEnumerable<WeeklyMenu>> GetWeeklyMenuAsync()
        {
            var weeklyMenu = await _context.WeeklyMenus
                .Include(wm => wm.DailyMenus)
                    .ThenInclude(dm => dm.MenuItems)
                .ToListAsync();

            return weeklyMenu;
        }

        public async Task<WeeklyMenu> GetById(int id)
        {
            var existingWeeklyMenu = await _context.WeeklyMenus
                .Include(wm => wm.DailyMenus)
                    .ThenInclude(dm => dm.MenuItems)
                .FirstOrDefaultAsync(wm => wm.Id == id);
            return existingWeeklyMenu;
        }

        public async Task Remove<T>(T entity) where T : class
        {
            _context.Set<T>().Remove(entity);
            await _context.SaveChangesAsync();
        }

        public async Task AddAsync<T>(T entity) where T : class
        {
            await _context.Set<T>().AddAsync(entity);
            await _context.SaveChangesAsync();
        }


    }
}