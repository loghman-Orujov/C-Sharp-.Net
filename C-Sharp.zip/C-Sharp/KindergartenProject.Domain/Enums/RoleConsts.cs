namespace KindergartenProject.Domain.EnumUserRoles
{
    public static class RoleConsts
    {
        public const string SchoolAdmin = "SchoolAdmin ";
        public const string Teacher = "Teacher ";
        public const string Parent = "Parent ";
    }
}