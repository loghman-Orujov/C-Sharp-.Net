using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Domain.Interfaces
{
    public interface IWeeklyMenuRepository : IBaseRepository<WeeklyMenu>
    {
        Task<WeeklyMenu> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate);
        Task<WeeklyMenu> CreateWeekly(WeeklyMenu weeklyMenu);
        Task<IEnumerable<WeeklyMenu>> GetWeeklyMenuAsync();
        Task UpdateAsync(WeeklyMenu updatedWeeklyMenu);
        Task<WeeklyMenu> GetById(int id);
        Task Remove<T>(T entity) where T : class;
        Task AddAsync<T>(T entity) where T : class;

    }
}