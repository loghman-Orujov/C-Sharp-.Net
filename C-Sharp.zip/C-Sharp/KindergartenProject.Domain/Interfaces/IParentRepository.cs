﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Domain.Interfaces
{
    public interface IParentRepository : IBaseRepository<Parent>
    {
       
    }
}
