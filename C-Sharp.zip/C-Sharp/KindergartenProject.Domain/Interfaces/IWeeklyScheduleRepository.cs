using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Domain.Interfaces
{
    public interface IWeeklyScheduleRepository : IBaseRepository<WeeklySchedule>
    {
        Task<WeeklySchedule> CreateWeeklySchedule(WeeklySchedule weeklySchedule);
        Task<WeeklySchedule> GetWeeklyMenuByDateRange(DateTime startDate, DateTime endDate);
        Task<IEnumerable<WeeklySchedule>> GetWeeklyMenuAsync();
        Task UpdateAsync(WeeklySchedule updatedWeeklySchedule);
        Task<WeeklySchedule> GetById(int id);
        Task Remove<T>(T entity) where T : class;
        Task AddAsync<T>(T entity) where T : class;
    }
}