﻿using KindergartenProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Interfaces
{
    public interface IAttendanceRepository : IBaseRepository<Attendance>
    {
        Task<IEnumerable<Attendance>> StudentAsync(int studentId);
        Task<IEnumerable<Attendance>> GetByClassroomIdAsync(int classroomId);
       Task<IEnumerable<Attendance>> DailyAsync(DateTime date);
        Task<bool> AttendanceExistsAsync(int studentId, DateTime date);
         Task<bool> EditAsync(Attendance attendance);

    }
}
