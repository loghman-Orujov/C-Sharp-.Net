using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KindergartenProject.Domain.Entities;

namespace KindergartenProject.Domain.Interfaces
{
    public interface IClassroomRepository:IBaseRepository<Classroom>
    {
        Task<IEnumerable<Classroom>> GetClassroomsByTeacherIdAsync(int teacherId);

    }
}