﻿using KindergartenProject.Domain.Entities;
using KindergartenProject.Domain.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Repositories
{
    public interface IObservationRepository : IBaseRepository<ObservationNote>
    {
        Task<List<ObservationNote>> GetByStudentIdAsync(int studentId);
    }
}
