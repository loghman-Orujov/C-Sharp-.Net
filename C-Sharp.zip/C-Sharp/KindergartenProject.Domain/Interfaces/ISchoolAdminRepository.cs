﻿using KindergartenProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Interfaces
{
	public interface ISchoolAdminRepository : IBaseRepository<SchoolAdmin>
	{
		//eğer school admin'e özel bir repo işlemi olacaksa buraya işlenecek
	}
}
