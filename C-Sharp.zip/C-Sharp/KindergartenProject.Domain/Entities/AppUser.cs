
using KindergartenProject.Domain.EnumUserRoles;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

public class AppUser : IdentityUser<int>, IBaseEntity
{
    public string Password { get; set; } 
	public string FirstName { get; set; }
	public string LastName { get; set; }
	public string Gender { get; set; }
	public string UserRole { get; set; } //will be enum values
	public DateTime? CreatedDate { get; set; }
	public DateTime? UpdatedDate { get; set; }
	public DateTime? DeletedDate { get; set; }
	public bool IsActive { get; set; } = true;
}
