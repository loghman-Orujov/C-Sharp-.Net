using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class Classroom : IBaseEntity
    {
        public int ClassroomId { get; set; }
        public string ClassName { get; set; }
        public int Capacity { get; set; } 
        public bool IsActive { get; set; }=true;
        public int TeacherId { get; set; }  
        public Teacher? Teacher { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }

        public ICollection<Student> Students { get; set; } = new List<Student>();
        public ICollection<Attendance> Attendances { get; set; }
    }
}