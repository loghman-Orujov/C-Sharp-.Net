using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class DailySchedule : IBaseEntity
    {
        public int Id { get; set; }
        public DayOfWeek DayOfWeek { get; set; } 
        public int WeeklyScheduleId { get; set; }
        public WeeklySchedule WeeklySchedule { get; set; } 
        public List<Activity> Activities { get; set; } 
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
    }

}