﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
	public class Student : IBaseEntity
	{
		public int StudentId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Gender { get; set; }
		public int Age { get; set; }	
        public int SchoolNo { get; set; }
		public string? Allergies { get; set; }
		public string? Diseases { get; set; }
		public string BloodType	{ get; set; }
		public string? Medications { get; set; }
        public string? DietNotes { get; set; }
		public ICollection<StudentParent> StudentParents { get; set; } = new List<StudentParent>();
        public string EmergencyContact { get; set; }
        public bool IsActive { get; set; } =true;
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
		public int ClassroomId { get; set; } // FK
        public ICollection<ObservationNote> ObservationNotes { get; set; } //yeni eklendi
        public Classroom Classroom { get; set; }
		// Navigation property
    public ICollection<Attendance> Attendances { get; set; }
    }
}
