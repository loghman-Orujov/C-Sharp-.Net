using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class DailyMenu : IBaseEntity
    {

        public int Id { get; set; }
        public DayOfWeek DayOfWeek { get; set; }
        public List<MenuItem> MenuItems{ get; set; }=new List<MenuItem>();
        public int WeeklyMenuId { get; set; }
        public WeeklyMenu WeeklyMenu { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}