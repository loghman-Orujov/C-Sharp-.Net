using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class Activity : IBaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public string Description { get; set; } 
        public DateTime StartTime { get; set; } 
        public DateTime EndTime { get; set; } 
        public int DailyScheduleId { get; set; } 
        public DailySchedule DailySchedule { get; set; } 
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
    }

}