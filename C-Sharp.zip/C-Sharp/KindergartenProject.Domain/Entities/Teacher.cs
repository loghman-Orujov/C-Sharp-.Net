using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class Teacher : AppUser, IBaseEntity
    {
        public string SubjectSpecialization { get; set; }

        //public Classroom? Classroom { get; set; }

    }
}