using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class MenuItem:IBaseEntity
    {
        public int Id { get; set; }
        public int Calories { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public DailyMenu DailyMenu { get; set; }
        public int DailyMenuId { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedDate{ get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}