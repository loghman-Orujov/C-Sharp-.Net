﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergartenProject.Domain.Entities
{
    public class StudentParent : IBaseEntity
    {
        public int StudentParentId { get; set; }
        public int StudentId { get; set; }
        public Student? Student { get; set; }
        public int ParentId { get; set; }
        public Parent? Parent { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}
