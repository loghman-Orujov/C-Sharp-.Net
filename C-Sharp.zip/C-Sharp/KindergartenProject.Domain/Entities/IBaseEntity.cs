﻿public interface IBaseEntity
{
	public bool IsActive { get; set; } 
	public DateTime? CreatedDate { get; set; } 
	public DateTime? UpdatedDate { get; set; }
	public DateTime? DeletedDate { get; set; }
}